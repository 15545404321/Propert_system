<?php

namespace Qiniu\Enum;

final class SplitUploadVersion extends QiniuEnum
{
    const V1 = 'v1';
    const V2 = 'v2';
}
