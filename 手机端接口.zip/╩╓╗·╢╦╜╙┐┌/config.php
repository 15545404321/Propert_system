<?php
return array (
  'WEBNAME' => '',
  'USERNAME' => '',
  'USERPWD' => '',
  'CJSJ' => '',
  'CJRS' => '',
  'SITE_KSSJ' => '',
  'SITE_JSSJ' => '',
  'INFO' => '',
);
?>