<?php
header("Content-type:text/html;charset=utf-8");
include('../core.php');

$Index = new Index();

$fun_name = I('get.c');

$Index->$fun_name();

class Index
{
    public function suggestion() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        if ($object) {

            $shop_id = $object['shop_id'];
            $member_id = $object['member_id'];
            $tsjy_tsnr = $object['tsjy_tsnr'];

            $d['shop_id'] = $shop_id;
            $d['member_id'] = $member_id;
            $d['tsjy_tsnr'] = $tsjy_tsnr;

            D('tsjy', $d, '+');
            J('','提交成功',200);

        } else {
            J('','请求方式错误',400);
        }

    }
}
