<?php

return array(
    'DB_HOST' => '127.0.0.1',
    'DB_USER' => 'newwy',
    'DB_PASS' => 'Sb4MSDH6X4C7Grxc',
    'DB_BASE' => 'newwy',
    'PREFIX' => 'cd_',
    'FILE_DOMAIN' => 'http://newwy.jf.ivimoo.com',
);
?>