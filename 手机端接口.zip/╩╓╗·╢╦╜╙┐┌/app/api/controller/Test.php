<?php

class Test
{
    public function index() {

        $shop_id = $_GET['shop_id'];
        $search_text= $_GET['text'];
        $type = $_GET['type'];

        $d['shop_id'] = $shop_id;

        $d['bmdh_title'] = ['like',$search_text];

        if ($type != 0) {

            $d['dhfl_id'] = $type;

        }

        $re = D('bmdh', $d);

        $res = $re;

        J($res,'获取成功',200);

    }

    public function testSessionOne() {
        $user_id = $_GET['user_id'];
        $_SESSION['username'] = 'name';
        $_SESSION['userid'] = $user_id;
        dump($_SESSION);

    }

    public function testSessionTwo() {
//        $userid = $_SESSION['userid'];
//        $userid = $_SESSION['userid'];
        dump($_SESSION['member']['member_id']);
    }


}