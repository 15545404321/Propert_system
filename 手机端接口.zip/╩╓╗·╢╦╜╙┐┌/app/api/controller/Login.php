<?php

use utils\wxoauth\WxOauth;

class Login
{
    public function oalogin () {

        // 需要传参 shop_id ，判断 appid 及 获取 member 表信息

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $shop_id = $object['shop_id'];
        $where_wxpz = [];
        $where_wxpz['shop_id'] = $shop_id;
        $where_wxpz['select'] = 'app_id,secret';
        $wxpz = D('wxpz',$where_wxpz);

        $appid = $wxpz[0]['app_id'];// appid
        $appsecret = $wxpz[0]['secret'];// appsecret

        $WxOauth = new WxOauth($appid,$appsecret);

        if (isset($object['code']) && !empty($object['code'])) {
            $res = $WxOauth->getToken($object['code']);

            $openid = $res['openid'];

            if (empty($openid)) {
                J($res,'参数错误，openid获取失败',400);
            }

            $d['shop_id'] = $shop_id;
//            $d['member_rzzt'] = 1;
            $d['openid'] = $openid;

            $re = D('member', $d);
            $res['member_id'] = $re[0]['member_id'];
            $res['xqgl_id'] = $re[0]['xqgl_id'];
            $res['shop_id'] = $re[0]['shop_id'];
            $res['member_rzzt'] = $re[0]['member_rzzt'];

            if (!empty($re)) {
//                J($openid,'未注册用户',201);
                if ($res['member_rzzt'] == 0) {
                    J($res,'审核中，请联系物业沟通',201);
                }
                $_SESSION['member'] = $res;
                J($res,'获取成功',200);
            } else {
                J($openid,'未注册用户',201);
            }

        } else {
            $redirect_uri = 'http://wyqt.jf.ivimoo.com/mobile/#/pages/login/login';
            $uri = $WxOauth->getCode($redirect_uri);
            J($uri,'获取成功',200);
        }
    }


    public function claim() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $xq_lou_dan_fc = $object['address'];
        $checked = $object['radioValue'];
        $openid = $object['openid'];
        $rz_name = $object['hzname'];

        $xq_lou_dan_fc = $xq_lou_dan_fc['proIndex'].','.$xq_lou_dan_fc['cityIndex'].','.
            $xq_lou_dan_fc['areaIndex'].','.$xq_lou_dan_fc['streetIndex'];

        $xq_lou_dan_fc_arr = explode(',',$xq_lou_dan_fc);

        $d['fcxx_id'] = $xq_lou_dan_fc_arr[3];

        $fcxx = D('fcxx', $d);

        $member_id = $fcxx[0]['member_id'];
        $shop_id = $fcxx[0]['shop_id'];
        $xqgl_id = $fcxx[0]['xqgl_id'];


        if (empty($member_id)) { // 如果 该房产信息 没有户主

//            建立 member 一条新数据，认证状态为[未认证]]
            if ($checked == 1)  { // 如果是户主

                $insert['khlx_id'] = 1;
                $insert['openid'] = $openid;
                $insert['shop_id'] = $shop_id;
                $insert['xqgl_id'] = $xqgl_id;
                $insert['member_name'] = $rz_name;
                $insert['member_rzzt'] = 0;
                $member_id = D('member', $insert, '+'); // 创建 并 认领会员信息

                // 同时将房产改为我
                $update_fcxx_member['member_id'] = $member_id;
                D('fcxx',$update_fcxx_member,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));

                // TODO J

            } else { // 如果不是户主，建立2条，将member_idx 写入该用户id

                // 建立自己信息
                $insert1['khlx_id'] = $checked;
                $insert1['openid'] = $openid;

                $insert1['shop_id'] = $shop_id;
                $insert1['xqgl_id'] = $xqgl_id;

                $insert1['member_rzzt'] = 0;
                $insert1['member_name'] = $rz_name;
                $member_id = D('member', $insert1, '+'); // 创建 并 认领会员信息

                // 建立户主信息、并把家庭成员加上我
                $insert1['member_idx'] = $member_id;
                $insert1['member_name'] = $fcxx[0]['fcxx_fjbh'].'户主';
                $member_id_main = D('member', $insert1, '+'); // 户主、加家庭成员 这时户主的openid==null;

                // 同时将房产改为我的户主
                $update_fcxx_member1['member_id'] = $member_id_main;
                D('fcxx',$update_fcxx_member1,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
            }

        } else { // 有户主

            $w['member_id'] = $member_id; // 户主的id
            $member_info = D('member',$w);

            if (!empty($member_info[0]['openid'])) { // 户主申请认证了
                // 查询 提交人的 openid
                if ($checked != 1) { // 家庭成员

                    // 查询本物业小区是否有我的信息
                    $select['openid'] = $openid;
                    $select['xqgl_id'] = $xqgl_id;
                    $member_wo = D('member',$select); // 我的信息

                    if (empty($member_wo)) {
                        // 如果没有我，创建我的会员数据
                        $insert1['khlx_id'] = $checked;
                        $insert1['openid'] = $openid;

                        $insert1['shop_id'] = $shop_id;
                        $insert1['xqgl_id'] = $xqgl_id;
                        $insert1['member_rzzt'] = 0;
                        $insert1['member_name'] = $rz_name;
                        $member_id_wo = D('member', $insert1, '+'); // 创建 并 认领会员信息

                        // 将我的户主的家庭成员加上我
                        $member_idx_arr = explode(',',$member_info[0]['member_idx']);
                        $member_idx_arr[] = $member_id_wo;
                        $update_main['member_idx'] = implode(',',array_unique($member_idx_arr)); // 户主信息的家庭成员 里添加我的id
                        D('member',$update_main,array('member_id'=>$member_id));

                    } else {
                        if($member_info[0]['openid'] == $openid) {
                            J('','您已经绑定过该房产',400);
                        } else {
                            J('','该房产已申请户主，如果不是您本人，请联系物业确认',400);
                        }
                    }

                    $update_fcxx_member1['member_id'] = $member_id;
                    D('fcxx',$update_fcxx_member1,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
                } else {
                    if($member_info[0]['openid'] == $openid) {
                        J('','您已经绑定过该房产',400);
                    } else {
                        J('','该房产已申请户主，如果不是您本人，请联系物业确认',400);
                    }
                }
            } else {
                // 户主已绑定 但未认领
                $up_date['openid'] = $openid;
                $up_date['member_name'] = $rz_name;
                $up_date['member_rzzt'] = 0;
                D('member',$up_date,array('member_id'=>$member_id));

                J('','认领已申请',200);
            }

        }

        switch ($checked) {
            case 1 :
                $fcxx_update['member_id'] = $member_id;
                D('fcxx',$fcxx_update,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
                break;
            case 2 :
            case 3 :
                if (empty($member_id)) {
                    J('','请先关联业主',400);
                }

                $member_idx_arr = explode(',',$fcxx[0]['member_idx']);

                $member_idx_arr[] = $member_id;

                $member_idx = implode(',',array_unique($member_idx_arr));

                $fcxx_update1['member_idx'] = $member_idx;

                D('fcxx',$fcxx_update1,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
                break;
        }

        J('','',200);
    }

    public function isLogin() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        if (isset($_SESSION['member']) && !empty($_SESSION['member'])) {

            if ($object['shop_id'] == $_SESSION['member']['shop_id']) {
                J('yes','',200);
            }

            J('no','',200);
        }else{

            J('no','',200);
        }
    }

    public function getLDFLists() {

        $shop_id = $_GET['shop_id'];

        // 小区
        $where_xqgl = [];
        $where_xqgl['shop_id'] = $shop_id;
        $where_xqgl['select'] = 'xqgl_id,xqgl_name';
        $where_xqgl['order'] = 'xqgl_id asc';
        $xqgl_temp = D('xqgl',$where_xqgl);

        // 楼宇
        $where_louyu = [];
        $where_louyu['shop_id'] = $shop_id;
        $where_louyu['louyu_pid'] = 'is null';
        $where_louyu['select'] = 'louyu_id,louyu_name,xqgl_id,louyu_pid';
        $where_xqgl['order'] = 'louyu_id asc';
        $louyu_temp = D('louyu',$where_louyu);

        // 单元
        $where_danyaun = [];
        $where_danyaun['shop_id'] = $shop_id;
        $where_danyaun['louyu_pid'] = 'is not null';
        $where_danyaun['select'] = 'louyu_id,louyu_name,louyu_pid';
        $where_xqgl['order'] = 'louyu_id asc';
        $danyaun_temp = D('louyu',$where_danyaun);

        // 房间
        $where_fcxx = [];
        $where_fcxx['shop_id'] = $shop_id;
        $where_fcxx['select'] = 'fcxx_id,fcxx_fjbh,louyu_id';
        $where_xqgl['order'] = 'fcxx_id asc';
        $fcxx_temp = D('fcxx',$where_fcxx);

        $xqgl = [];
        $louyu = [];
        $danyaun = [];
        $fcxx = [];

        foreach ($xqgl_temp as $xqgl_temp_item) {
            $xqgl[$xqgl_temp_item['xqgl_id']] = [
                'value' => $xqgl_temp_item['xqgl_id'],
                'label' => $xqgl_temp_item['xqgl_name'],
            ];
        }

        foreach ($louyu_temp as $louyu_temp_item) {

            $louyu[$louyu_temp_item['xqgl_id']][] = [
                'value' => $louyu_temp_item['louyu_id'],
                'label' => $louyu_temp_item['louyu_name'],
            ];

            $danyaun[$louyu_temp_item['louyu_id']][] = [
                'value' => $louyu_temp_item['louyu_id'],
                'label' => '商服/车库',
            ];

        }

        foreach ($danyaun_temp as $danyaun_temp_item) {
            $danyaun[$danyaun_temp_item['louyu_pid']][] = [
                'value' => $danyaun_temp_item['louyu_id'],
                'label' => $danyaun_temp_item['louyu_name'],
            ];
        }

        foreach ($fcxx_temp as $fcxx_temp_item) {
            $fcxx[$fcxx_temp_item['louyu_id']][] = [
                'value' => $fcxx_temp_item['fcxx_id'],
                'label' => $fcxx_temp_item['fcxx_fjbh'],
            ];
        }

        $data = [];
        $data['xqgl'] = $xqgl;
        $data['louyu'] = $louyu;
        $data['danyaun'] = $danyaun;
        $data['fcxx'] = $fcxx;

        J($data,'获取成功',200);
    }
}
/*
 * 1 判断是否登录，已登录就无需登录，否则调用登录接口
 * 2 登录接口查询获取openid
 * 3 用openid去 member 表查是否存在相关数据
 * 4 如果有则登录完成
 * 5 如果没有则将openid 返给前端
 * 6 前端和者选着的房产信息一起提交后台
 * 6.1 获取小区数据
 * 6.2 提交
 * 7 之后过程如图
 * 7.1 并标注默认登录小区
 *
 * 8 后台认证状态审核
 * 9 切换小区 切换 member_id 和 xqgl_id，并标注为下次默认登录小区
 * 10 第一次登录该小区需要审核
 * 11 member 表加 openid,认证状态
 * */

/*
 * 在用户表建立两个字段(openid、认证状态)
 * 进入系统
 *      查询 member表，有没有 openid 等我的
 *      如果没有{
 *          让选择房产信息，
 *          根据房产信息的 member_id，找用户
 *          如果有用户{
 *              更改用户的 openid，更改认证状态为[未认证]
 *          }如果没有{
 *              建立 member 一条新数据，认证状态为[未认证]
 *          }
 *          如果提交的信息，是业主{
 *              关联房产信息，修改 member_id
 *          }不是业主{
 *              查询有没有业主
 *              如果有业主{
 *                  关联房产信息，修改 member_idx
 *              } else {
 *                  提示“请先关联业主
 *              }
 *          }
 *      }
 * */
