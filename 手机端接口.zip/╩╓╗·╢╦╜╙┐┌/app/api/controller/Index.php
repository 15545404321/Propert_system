<?php

class Index
{
    public function suggestion() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        if ($object) {

            $shop_id = $object['shop_id'];
//            $member_id = $object['member_id'];
            $member_id = $_SESSION['member']['member_id'];
            $tsjy_tsnr = $object['tsjy_tsnr'];

            $d['shop_id'] = $shop_id;
            $d['member_id'] = $member_id;
            $d['tsjy_tsnr'] = $tsjy_tsnr;

            D('tsjy', $d, '+');
            J('','提交成功',200);

        } else {
            J('','请求方式错误',400);
        }

    }


    public function getXqglList() {

        $shop_id = $_GET['shop_id'];

        $d['shop_id'] = $shop_id;
        $d['select'] = 'xqgl_id,xqgl_name';

        $xqgl = D('xqgl', $d);

        J($xqgl,'提交成功',200);

    }


    public function getShopInfo() {

        $shop_id = $_GET['shop_id'];

        $d['shop_id'] = $shop_id;

        $xqgl = D('shop', $d);

        J($xqgl,'提交成功',200);
    }


    public function indexDiy() {

        $shop_id = $_GET['shop_id'];
        $d['r.shop_id'] = $shop_id;
        $d['join'] = [
            C('PREFIX').'decoconfig d' => 'r.renovation_page=d.decoconfig_id'
        ];
        $renovation = D('renovation r', $d);

        $ad_img = [];
        $nav = [];
        $three = [];
        $application = [];
        $background = '';

        foreach ( $renovation as $renovation_key => $renovation_item ) {

            /*$extra = [];
            $extra[]['place'] = $renovation_item['decoconfig_place']??'';

            $renovation_extra = json_decode($renovation_item['renovation_extra'],true);

            if (!empty($renovation_extra)) {
                foreach ($renovation_extra as $renovation_extra_item ) {
                    $extra[] = [
                        $renovation_extra_item['key'] => $renovation_extra_item['val']
                    ];
                }
            }*/

            $extra = '';

            if (!empty($renovation_item['renovation_place'])) {
                $extra .= '?place='.$renovation_item['renovation_place'];
            }

            if (!empty($renovation_item['renovation_extra'])) {

                if (!strstr($extra,'?')) {
                    $extra .= '?';
                } else {
                    $extra .= '&';
                }

                $renovation_extra = json_decode($renovation_item['renovation_extra'],true);

                if (!empty($renovation_extra)) {
                    foreach ($renovation_extra as $renovation_extra_key => $renovation_extra_item ) {
                        if ($renovation_extra_key != 0) {
                            $extra .= '&';
                        }
                        $extra .= $renovation_extra_item['key'].'='.$renovation_extra_item['val'];
                    }
                }
            }


            if (!strstr($renovation_item['renovation_image'],"http")) {
                $renovation_item['renovation_image'] =
                    str_replace('/uploads/',
                        C('FILE_DOMAIN').'/uploads/',
                        $renovation_item['renovation_image']);
            }

            switch ($renovation_item['renovation_type']) {
                case 1:
                    $nav[] = [
                        'title'     => $renovation_item['renovation_name'],
                        'synopsis'  => $renovation_item['renovation_synopsis'],
                        'url'       => $renovation_item['renovation_image'],
                        'position'  => $renovation_item['decoconfig_url'].$extra,
                        'page'      => $renovation_item['decoconfig_type'],
                    ];
                    break;
                case 2:
                    $three[] = [
                        'title'     => $renovation_item['renovation_name'],
                        'synopsis'  => $renovation_item['renovation_synopsis'],
                        'url'       => $renovation_item['renovation_image'],
                        'position'  => $renovation_item['decoconfig_url'].$extra,
                        'page'      => $renovation_item['decoconfig_type'],
                    ];
                    break;
                case 3:
                    $application[] = [
                        'title'     => $renovation_item['renovation_name'],
                        'synopsis'  => $renovation_item['renovation_synopsis'],
                        'url'       => $renovation_item['renovation_image'],
                        'position'  => $renovation_item['decoconfig_url'].$extra,
                        'page'      => $renovation_item['decoconfig_type'],
                    ];
                    break;
                case 4:
                    $ad_img = [
                        'title'     => $renovation_item['renovation_name'],
                        'synopsis'  => $renovation_item['renovation_synopsis'],
                        'url'       => $renovation_item['renovation_image'],
                        'position'  => $renovation_item['decoconfig_url'].$extra,
                        'page'      => $renovation_item['decoconfig_type'],
                    ];
                    break;
                case 5:
                    $background = $renovation_item['renovation_image'];
                    break;
            }

        }

        $data = [
            'background'    => $background,
            'nav'           => $nav,
            'three'         => $three,
            'application'   => $application,
            'ad_img'        => $ad_img,
        ];

        J($data,'查询成功',200);

    }
}
