<?php

class Expense
{
    public function index() {

        $shop_id = $_GET['shop_id'];
        $xqgl_id = $_GET['xqgl_id'];
        $yssj_stuats = $_GET['yssj_stuats'];
        $pages = $_GET['pages'];
        $limit = 10;

        $d['limit1'] = $limit * ( $pages - 1 );
        $d['limit2'] = $d['limit1'] + $limit;

        $d['y.shop_id'] = $shop_id;
        $d['y.xqgl_id'] = $xqgl_id;
        $d['m.member_id'] = $_SESSION['member']['member_id'];

        $d['y.yssj_stuats'] = $yssj_stuats;

        $d['join'] = [
            C('PREFIX').'member m' => 'y.member_id=m.member_id',
            C('PREFIX').'cewei c' => 'y.cewei_id=c.cewei_id',
            C('PREFIX').'fcxx f' => 'y.fcxx_id=f.fcxx_id',

            C('PREFIX').'louyu d' => 'f.louyu_id=d.louyu_id',

            C('PREFIX').'tccd t' => 'c.tccd_id=t.tccd_id',
            C('PREFIX').'cwqy q' => 'c.cwqy_id=q.cwqy_id',
        ];

        $table = D('yssj y', $d);

        $ta1 = $table;

        foreach ($table as $table_key => $table_item) {

            if ($table_item['sjlx_id'] == 1) {
                $ta1[$table_key]['zcbh'] = $table_item['louyu_lyqz'] . '-' . $table_item['louyu_name'] . '-' . $table_item['fcxx_fjbh'];
            }
            if ($table_item['sjlx_id'] == 2) {
                $ta1[$table_key]['zcbh'] = $table_item['tccd_name'] . '-' . $table_item['cwqy_name'] . '-' . $table_item['cewei_name'];
            }

            $ta1[$table_key]['yssj_kstime'] = date('Y-m-d',$table_item['yssj_kstime']);
            $ta1[$table_key]['yssj_jztime'] = date('Y-m-d',$table_item['yssj_jztime']);
            $ta1[$table_key]['yssj_fksj'] = !empty($table_item['yssj_fksj'])?date('Y-m-d',$table_item['yssj_fksj']):'未付款';
        }

//        dump($ta1);exit;
        J($ta1,'获取成功',200);
    }


    public function paymentQuery() {

        $shop_id = $_GET['shop_id'];
        $xqgl_id = $_GET['xqgl_id'];
        $yssj_stuats = 0;

        $d['y.shop_id'] = $shop_id;
        $d['y.xqgl_id'] = $xqgl_id;
        $d['m.member_id'] = $_SESSION['member']['member_id'];

        $d['y.yssj_stuats'] = $yssj_stuats;

        $d['join'] = [
            C('PREFIX').'xqgl x' => 'y.xqgl_id=x.xqgl_id',
            C('PREFIX').'member m' => 'y.member_id=m.member_id',

            C('PREFIX').'fcxx f' => 'y.fcxx_id=f.fcxx_id',
            C('PREFIX').'cewei c' => 'y.cewei_id=c.cewei_id',


            C('PREFIX').'louyu d' => 'f.louyu_id=d.louyu_id',

            C('PREFIX').'tccd t' => 'c.tccd_id=t.tccd_id',
            C('PREFIX').'cwqy q' => 'c.cwqy_id=q.cwqy_id',
        ];

        $d['group'] = 'y.yssj_fymc,y.cewei_id,y.fcxx_id';
        $d['select'] = 'y.sjlx_id,y.fcxx_id,y.member_id,y.yssj_fymc,sum(y.yssj_ysje) as yssj_ysje,min(y.yssj_kstime) as yssj_kstime,max(y.yssj_jztime) as yssj_jztime,y.yssj_fydj,y.cbgl_id,y.cewei_id,m.member_name,m.member_tel,f.fcxx_fjbh,f.louyu_id,d.*,t.*,q.*,x.*';

        $table = D('yssj y', $d);

        $ta1 = $table;

        foreach ($table as $table_key => $table_item) {

            if ($table_item['sjlx_id'] == 1) {
                $ta1[$table_key]['zcbh'] = $table_item['louyu_lyqz'] . '-' . $table_item['louyu_name'] . '-' . $table_item['fcxx_fjbh'];
            }
            if ($table_item['sjlx_id'] == 2) {
                $ta1[$table_key]['zcbh'] = $table_item['tccd_name'] . '-' . $table_item['cwqy_name'] . '-' . $table_item['cewei_name'];
            }

            $ta1[$table_key]['yssj_kstime'] = date('Y-m-d',$table_item['yssj_kstime']);
            $ta1[$table_key]['yssj_jztime'] = date('Y-m-d',$table_item['yssj_jztime']);
            $ta1[$table_key]['yssj_fksj'] = !empty($table_item['yssj_fksj'])?date('Y-m-d',$table_item['yssj_fksj']):'未付款';
        }

        J($ta1,'获取成功',200);
    }

}
