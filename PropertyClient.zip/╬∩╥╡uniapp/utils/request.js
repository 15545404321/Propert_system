import axios from 'axios'
const instance = axios.create({
	baseURL: 'http://wyqt.jf.ivimoo.com/api/',
	timeout: 10000,
	header: {
		'content-type': 'application/json'
	}
})

export default instance
