// 获取页面 get 参数
export function getParam(param) {
	var reg = new RegExp('(^|&)' + param + '=([^&]*)(&|$)')
	var value = window.location.search.substr(1).match(reg)
	if (value != null && value != undefined) return unescape(value[2])
	return null
}

// 数组去重
export function removeRepeat(arr) {
	const map = new Map()
	return arr.filter(item => !map.has(item.oilnumber) && map.set(item.oilnumber, 1))
}

// 地址转换
export function decrypt(bdLon, bdLat) {
	var x_pi = 3.14159265358979324 * 3000.0 / 180.0
	var x = bdLon - 0.0065
	var y = bdLat - 0.006
	var z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi)
	var theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi)
	var gcjLon = z * Math.cos(theta)
	var gcjLat = z * Math.sin(theta)
	return {
		lon: gcjLon,
		lat: gcjLat
	}
}
