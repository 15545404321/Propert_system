<script>
	import {
		isLogin
	} from '@/common/api'
	import Cache from '@/utils/cache'
	export default {
		onLaunch: function(res) {
			console.log('App Launch',res)
			
			uni.onTabBarMidButtonTap(function(e) {
				uni.navigateTo({
					url:'/pages/apply/apply'
				})
			})
			
			if(res.query.shop_id && !Cache.get('shop_id') && res.query.shop_id != Cache.get('shop_id')) {
				Cache.set('shop_id',res.query.shop_id)
			} else if(!res.query.shop_id && !Cache.get('shop_id')) {
				console.log('shop_id参数错误，请检查网站链接地址');
				return;
			}
			
		},
		onShow: function(res) {
			console.log('App Show',res)
			console.log('data-shop_id',Cache.get('shop_id'));
			
			var url = decodeURI(window.location.href);
			var reg = /[?&]([^?&#]+)=([^?&#]+)/g;
			var params = {};
			var ret = reg.exec(url);
			while (ret) {
			    params[ret[1]] = ret[2];
			    ret = reg.exec(url);
			}
			let code = {
			    code: params['code'],
			}
			
			if(!code.code) {
				isLogin({shop_id:Cache.get('shop_id')}).then( res_is_login => {
					if(res_is_login.data.data == 'no'){
						uni.showToast({
							title: '授权登录',
							icon:'none'
						});
						uni.navigateTo({
							url:'/pages/login/login'
						})
					}
				})
			}
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
	page{
		background-color: #f1f1f1;
	}
</style>
