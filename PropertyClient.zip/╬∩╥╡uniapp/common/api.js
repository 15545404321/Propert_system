import request from '@/utils/request'

/* Test */
export function getTestindex(data) {
	return request.get('Test/index', {
		params: data
	})
}


/* Formal */
export function getLDFLists(data) {
	return request.get('login/getLDFLists', {
		params: data
	})
}

export function isLogin(data){
	console.log('data',data);
	return request.post('login/isLogin', data)
}

export function oaLogin(data){
	console.log('data',data);
	return request.post('login/oalogin', data)
}

export function claim(data){
	console.log('data',data);
	return request.post('login/claim', data)
}

// 投诉建议
export function suggestion(data){
	return request.post('Index/suggestion', data)
}

// 物业新闻
export function wyNewsList(data) {
	return request.get('Report/wyNewsList', {
		params: data
	})
}
// 物业新闻详情
export function wyNewsListInfo(data) {
	return request.get('Report/newsDetails', {
		params: data
	})
}

// 服务月报
export function Report(data) {
	return request.get('Report/index', {
		params: data
	})
}
// 服务月报详情
export function ReportInfo(data) {
	return request.get('Report/details', {
		params: data
	})
}

// 招聘信息
export function recruitNewsList(data) {
	return request.get('Report/recruitNewsList', {
		params: data
	})
}
// 招聘信息详情
export function recruitNewsListInfo(data) {
	return request.get('Report/recruitDetails', {
		params: data
	})
}

// 便民电话
export function ConTel(data) {
	return request.get('ConTel/index', {
		params: data
	})
}

// 费用查询
export function Expense(data) {
	return request.get('Expense/index', {
		params: data
	})
}
// 报修查询
export function repairSearch(data) {
	return request.get('Report/repairSearch', {
		params: data
	})
}
// 问题分类
export function bxFl(data) {
	return request.get('Report/bxFl', {
		params: data
	})
}
// 上传报修
export function Upload(data) {
	return request.post('Report/submitBx', data)
}
// 获取小区
export function getXqglList(data) {
	return request.get('index/getXqglList', {
		params: data
	})
}
// 联系我们
export function getShopInfo(data) {
	return request.get('index/getShopInfo', {
		params: data
	})
}
// 缴费查询
export function pay(data) {
	return request.get('Expense/paymentQuery', {
		params: data
	})
}

// 首页变活
export function indexLive(data) {
	return request.get('index/indexDiy', {
		params: data
	})
}
// 广告变活
export function AdManage(data) {
	return request.get('AdManage/index', {
		params: data
	})
}