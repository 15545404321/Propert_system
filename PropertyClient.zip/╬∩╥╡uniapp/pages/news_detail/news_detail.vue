<template>
	<view>
		<image class="banner" src="/static/image/header.png" mode="widthFix"></image>
		<view class="box">
			<view class="h1">{{wzgl_title}}</view>
			<view class="h6">
				<view class="date">{{wzgl_time}}</view>
			</view>
			<view class="detail">
				<view class="text" v-html="wzgl_neirong"></view>
			</view>
		</view>

	</view>
</template>

<script>
	
	import Cache from '@/utils/cache'
	import { wyNewsListInfo } from '../../common/api';
	export default {
		data() {
			return {
				wzgl_title : '',
				wzgl_time : '',
				wzgl_neirong : '',
			}
		},
		onLoad(options) {
			const shop_id = Cache.get('shop_id');
			let obj = {
				shop_id,
				wzgl_id : options.wzgl_id
			}
			wyNewsListInfo(obj)
			.then(res=>{
				this.wzgl_title = res.data.data.wzgl_title
				this.wzgl_time = res.data.data.wzgl_time
				this.wzgl_neirong = res.data.data.wzgl_neirong
				
			})
		},
		methods: {
			
		}
	}
</script>

<style>
	.text >>> img {
		width: 100%;
		height: 100%;
	}
	/* 背景 */
	.banner {
		width: 100%;
	}

	/* 内容 */
	.box {
		background-color: #fff;
		margin: 20rpx;
		padding: 30rpx;
	}

	/* 标题 */
	.h1 {
		font-size: 32rpx;
		font-weight: 600;
		/* display: -webkit-box;
		text-overflow: ellipsis;
		overflow: hidden;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1; */
		margin: 20rpx 0;
	}

	/* 标题结束 */
	/* 时间 */
	.h6 {
		display: flex;
		font-size: 26rpx;
		color: #c1c1c1;
		margin: 20rpx 0;
	}

	/* 时间结束 */
	/* 内容文本 */
	.detail {
		background-color: #fffcf1;
		border: #fea01a 2rpx dashed;
		padding: 30rpx;
		border-radius: 10rpx;
		font-size: 28rpx;
		line-height: 45rpx;
		color: #303030;
		text-align: justify;
		text-align-last: left;
		margin-top: 30rpx;
	}
	.h3 {
		margin: 10rpx 0;
	}
	/* 内容文本结束 */
	/* 内容图片 */
	.images {
		margin: 20rpx 0;
	}
	.images image {
		width: 30%;
		margin: 0 10rpx;
	}
	/* 内容图片结束 */
	
	/* 内容结束 */
</style>
