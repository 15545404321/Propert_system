<template>
	<view class="boxes">
	        <image class="banner" src="../../static/image/header.png" mode="widthFix"></image>
	        <!-- <van-dropdown-menu>
	            <van-dropdown-item v-model="value1" :options="option1" />
	        </van-dropdown-menu> -->
	        <view class="box">
	            <template v-for="(v, i) in list">
	                <view class="newText" @click="showPopup(v.wzgl_id)">
	                    <view>
	                        <view class="photoTitle">
	                            <image src="../../static/image/book.png" mode="widthFix" class="book"></image>
	                            <view class="el">{{v.wzgl_title}}</view>
	                        </view>
	                        <view class="el info">{{v.wzgl_futitle}}</view>
	                        <view class="timer">
	                            <view>{{v.wzgl_time}}</view>
	                        </view>
	                    </view>
						<image v-if="v.wzgl_img != ''" :src="v.wzgl_img" mode="widthFix" class="show"></image>
						<image v-if="v.wzgl_img == ''" src="../../static/image/wutu.png" mode="widthFix" class="show"></image>
	                </view>
	            </template>
	        </view>
	    </view>
</template>

<script>
	import { recruitNewsList } from '../../common/api';
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
				list:[],
				pages:1
			}
		},
		onLoad() {
			this.getList()
		},
		methods: {
			// 获取列表
			getList(){
				let data = {
					pages : this.pages,
					shop_id : Cache.get('shop_id')
				}
				recruitNewsList(data)
				.then(res=>{
					console.log(res);
					this.list = [...this.list, ...res.data.data]
				})
			},
			showPopup(__id){
				// console.log(__id);
				uni.navigateTo({
					url:'/pages/recruit_detail/recruit_detail?wzgl_id=' + __id
				})
			}
		},
		// 触底的事件
		onReachBottom() {
			this.pages++
			this.getList()
		},
	}
</script>

<style>
.banner {
    width: 100%;
}
.el {
    flex: 1;
    text-overflow: -o-ellipsis-lastline;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    line-clamp: 1;
    -webkit-box-orient: vertical;
}

.header {
    width: 100%;
}

.fuwu {
    margin: 20rpx;
    border-radius: 5px;
    background: #fff;
    padding: 20rpx;
}

.fuwu image {
    width: 28%;
}

.box {
    margin: 10rpx 15rpx;
    border-radius: 10rpx;
    background: #fff;
    padding: 20rpx;
}

.newText {
    padding: 20rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #c6c6c6;
}
.newText:last-child{
	border: none;
}

.photoTitle {
    display: flex;
    align-items: center;
}

.photoTitle .book {
    width: 50rpx;
    margin-right: 10rpx;
}

.photoTitle view {
    font-size: 32rpx;
    color: #000;
}

.info {
    color: #989898;
    margin: 10rpx 0;
}

.timer {
    display: flex;
    align-items: center;
    color: #c1c1c1;
}

.timer view:nth-of-type(1) {
    margin-right: 20rpx;
}

.show {
    /* width: 25%; */
	width: 150rpx;
}
</style>
