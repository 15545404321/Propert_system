<template>
	<view>
		<image class="banner" src="../../static/image/header.png" mode="widthFix"></image>
		<view v-for="v in list">
			<view class="info">
				<view class="shu">
					<view>
						<view class="basic">
							<span>业主: </span>
							<span>{{v.member_name}}</span>
						</view>
						<view class="basic">
							<span>手机: </span>
							<span>{{v.member_tel}}</span>
						</view>
					</view>
					<view class="address">
						<!-- <view>水边独栋别墅</view> -->
						<!-- <view>E栋3-12-2</view> -->
						<image src="../../static/image/add.png" alt="" class="add" mode="widthFix"></image>
						<view>{{v.zcbh}}</view>
					</view>
				</view>
				<view>
					<view class="line">
						<view class="title">
							<image class="imgBig" v-if="v.fcxx_id != null && v.cbgl_id == null" src="../../static/image/fangzi.png" mode="widthFix"></image>
							<image class="imgBig" v-if="v.cewei_id != null"  src="../../static/image/cheliang.png" mode="widthFix"></image>
							<image class="imgBig" v-if="v.cbgl_id != null && v.fcxx_id != null" src="../../static/image/yibiao.png" mode="widthFix"></image>
						
							<view class="gang">
								<view>{{v.yssj_fymc}}</view>
								<view>|</view>
								<view class="el">{{v.yssj_fksj}}</view>
							</view>
						</view>
						<view class="money" style="color: #f92f2d;">
							<span style="margin-right: 3px;">应缴: </span>
							<span><span>￥</span>{{v.yssj_ysje}}</span>
						</view>
					</view>
					<!-- <view class="line">
						<view class="title">
							<view class="gang">
								<view>水费</view>
								<view>|</view>
								<view class="el">欠费</view>
							</view>
						</view>
						<view class="money" style="color: #f92f2d;">
							<span style="margin-right: 3px;">应缴: </span>
							<span><span>￥</span>15</span>
						</view>
					</view> -->
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import { pay } from '../../common/api'
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
				list:[]
			}
		},
		onLoad() {
			let obj = {
				shop_id: Cache.get('shop_id'),
				xqgl_id:Cache.get('xqgl_id'),
			}
			pay(obj)
			.then(res=>{
				console.log(res);
				this.list = res.data.data
			})
		},
		methods: {

		}
	}
</script>

<style>
	.banner {
		width: 100%;
	}

	.el {
		flex: 1;
		text-overflow: -o-ellipsis-lastline;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 1;
		line-clamp: 1;
		-webkit-box-orient: vertical;
	}

	.header {
		width: 100%;
	}

	.info {
		background: #fff;
		border-radius: 5px;
		margin: 20rpx;
		padding: 30rpx 30rpx 14rpx;
		position: relative;
	}

	.info::after {
		content: ' ';
		width: 10rpx;
		height: 110rpx;
		background: #fa2e2f;
		position: absolute;
		left: 0;
		top: 22rpx;
	}

	.shu {
		border-bottom: 1px dotted #cfcfcf;
		padding-bottom: 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.basic {
		color: #000;
		font-size: 32rpx;
		margin-left: 20rpx;
	}

	.basic:nth-of-type(2) {
		margin: 3px 0;
		margin-left: 20rpx;
	}

	.basic span:nth-of-type(1) {
		margin-right: 10rpx;
	}

	.address {
		color: #9b9b9b;
		margin-left: 20rpx;
		display: flex;
		flex-direction: column;
		align-items: flex-end;
		/* justify-content: flex-end; */
	}

	.add {
		width: 50rpx;
		margin-bottom: 8rpx;
	}

	.address view:nth-of-type(1) {
		margin-bottom: 6rpxx;
	}

	.line {
		padding-top: 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 12rpx;
	}

	.title {
		display: flex;
		align-items: center;
		font-size: 32rpx;
		color: #9b9b9b;
	}

	.title img {
		width: 40rpx;
		height: 40rpx;
		margin-right: 16rpx;
	}

	.money {
		display: flex;
		align-items: center;
		color: #9b9b9b;
		justify-content: flex-end;
		font-size: 32rpx;
		white-space:nowrap;
	}

	.money img {
		width: 11%;
		margin-left: 12rpx;
	}

	.gang {
		display: flex;
		align-items: center;
	}

	.gang view:nth-of-type(2) {
		margin: 0 10rpx;
	}
	.imgBig {
		width: 40rpx;
		margin-right: 10rpx;
	}
</style>
