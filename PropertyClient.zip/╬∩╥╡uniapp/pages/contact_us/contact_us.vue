<template>
	<view>
		<image class="banner" src="../../static/image/header.png" mode="widthFix"></image>
		<view class="textImg">
			<view class="title">众森物业联系电话</view>
			<view class="bs">
				<span>2023-1-29<span class="timer">11:13</span></span>
			</view>
			<view class="image">
				<view class="jc">尊敬的业主您好</view>
				<view class="lh">为了方便您与我们联系为各位业主提供手机号</view>
				<view>内容如下:</view>
				<view class="imgs">
					<template v-for="(v, i) in imgList">
						<view>
							<span>{{ v.shop_xlr }} </span>
							<span @click="Calltel(v.shop_tel)" class="phone">{{ v.shop_tel }}</span>
						</view>
					</template>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import { getShopInfo } from '../../common/api'
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
					imgList :[]
				}
			},
			onLoad() {
				let obj = {
					shop_id: Cache.get('shop_id')
				}
				getShopInfo(obj)
				.then(res=>{
					this.imgList = res.data.data
				})
			},
			methods: {
				Calltel(v){
					window.location.href = `tel://${v}`
				}
			}
		}
</script>

<style scoped>
	.banner {
		width: 100%;
	}

	.textImg {
		background: #fff;
		margin: 20rpx;
		border-radius: 10rpx;
		padding: 40rpx;
	}

	.title {
		font-size: 36rpx;
		font-weight: 800;
		margin-bottom: 12rpx;
	}

	.bs {
		color: #dddddd;
		margin-bottom: 24rpx;
	}

	.timer {
		margin: 0 20rpx;
	}

	.jc {
		margin-bottom: 10rpx;
	}

	.image {
		background: #fefff1;
		border: 1px dotted #bdb666;
		border-radius: 10rpx;
		padding: 30rpx;
		color: #000;
	}

	.lh {
		line-height: 40rpx;
	}

	.imgs {
		line-height: 80rpx;
		font-size: 40rpx;
	}

	.imgs>view {
		text-align: center;
	}

	.phone {
		color: #3838d7;
		margin-left: 10rpx;
	}
</style>
