<template>
	<view>
		<view v-if="isLoginShwo">
			<image class="banner" src="/static/image/header.png" mode="widthFix"></image>
			<view class="name_hz">
				<view>户主姓名</view>
				<input type="text" placeholder="请输入户主姓名" v-model="hzname">
			</view>
			<view class="name_hz" @click="selectAddress()">
				<view>选择房产</view>
				<input type="text" placeholder="请选择房产" v-model="address" disabled>
			</view>
			<view class="name_hz">
				<view>成员关系</view>
				<radio-group @change="handlRadio" style="margin-left: 20rpx;">
					<label>
						<radio value="1" />房主
					</label>
					<label>
						<radio value="2" />户主
					</label>
					<label>
						<radio value="3" />家庭成员
					</label>
				</radio-group>		
			</view>
			<view class="determine">
				<button size="mini" class="btn" @click="sub" v-if="submit" >点击提交</button>
			</view>
			<ehPicker @conceal="conceal" v-if="popup" />
		</view>		
		<view v-else style="background-color: white;"></view>
	</view>
</template>

<script>
	import {
		getLDFLists,oaLogin,isLogin,claim
	} from '@/common/api'
	import Cache from '@/utils/cache'
	import ehPicker from '@/components/erha-picker/erha-picker.vue';
	export default {
		components: {
			ehPicker
		},
		data() {
			return {
				popup: false,
				provinceDataOb: {},
				getCityOb: {},
				getAreaOb: {},
				getStreetsOb: {},
				address: '', // 选完的地址
				hzname: "", // 户主姓名
				radioValue: '', // 单选框的值
				openid:'',
				dataParam : {},
				submit: true,
				isLoginShwo:false
			}
		},
		onLoad(option) {
			isLogin({shop_id:Cache.get('shop_id')}).then( res_is_login => {
				if(res_is_login.data.data == 'yes'){
					window.location.href = 'http://wyqt.jf.ivimoo.com/mobile/#/'
				}
			})
			var url = decodeURI(window.location.href);
			var reg = /[?&]([^?&#]+)=([^?&#]+)/g;
			var params = {};
			var ret = reg.exec(url);
			while (ret) {
			    params[ret[1]] = ret[2];
			    ret = reg.exec(url);
			}
			let code = {
			    code: params['code'],
			}
			uni.showLoading({
				title: '登录验证中~'
			});
			if(code.code){
				oaLogin({
				    shop_id:Cache.get('shop_id'),
				    code: code.code
				}).then(res => {
					console.log('oaLogin-login-1::',res);
					setTimeout(function () {
						uni.hideLoading();
					}, 1000);
					if (res.data.state == 201) {
						uni.showToast({
							title: res.data.msg,
							icon:'none'
						});
						this.isLoginShwo = true
					    this.openid = res.data.data
						return
					} else if (res.data.state == 200) {
					    // window.localStorage.setItem('xqgl_id', res.data.data.xqgl_id) // 小区管理默认值
						console.log('res-1res',res);
						Cache.set('xqgl_id',res.data.data.xqgl_id)
						// window.location.href = 'http://wyqt.jf.ivimoo.com/mobile/#/'
						// window.location.replace('http://wyqt.jf.ivimoo.com/mobile/#/')
						window.history.replaceState(null, "", 'http://wyqt.jf.ivimoo.com/mobile/#/');
						window.history.go(0);
						/* uni.reLaunch({
							url: '/pages/index/index'
						}) */
						return
					} else if (res.data.data == 400) {
						uni.showToast({
							title: res.data.msg,
							icon:'none'
						});
						return
					}
				})
			} else {
				oaLogin({
				    shop_id:Cache.get('shop_id')
				}).then(res => {
					console.log('oaLogin-login-2::',res);
					window.location.href = res.data.data
				})
			}
		},
		methods: {
					
			// 单选框
			handlRadio(e) {
				this.radioValue = e.detail.value
			},
			// 选择房产
			selectAddress() {
				this.popup = true
			},
			conceal(param) {
				// 获取到传过来的 省 市 区 县数据
				console.log('login-param', param);
				let { area, city, province, street } = param
				this.address = province + ' ' + city + ' ' + area + ' ' + street
				this.dataParam = param
				// 选择完毕后隐藏
				this.popup = false;
			},
			// 点击提交
			sub(){
				if( this.hzname == '' ){
					uni.showToast({
						title:'请输入户主姓名',
						icon:'none'
					})
					return
				}
				if( this.address == '' ){
					uni.showToast({
						title:'请选择房产',
						icon:'none'
					})
					return
				}
				if( this.radioValue == '' ){
					uni.showToast({
						title:'请选择成员关系',
						icon:'none'
					})
					return
				}
				if( this.openid == '' ){
					uni.showToast({
						title:'openid:参数错误',
						icon:'none'
					})
					return
				}
				let obj = {
					hzname : this.hzname,
					address : this.dataParam,
					radioValue : this.radioValue,
					openid: this.openid
				}
				console.log(obj);
				claim(obj).then(res_claim => {
					if (res_claim.data.state == 200) {
					    console.log('res_claim',res_claim.data.data);
						// Cache.set('xqgl_id',res_claim.data.data.xqgl_id)
						/* uni.reLaunch({
							url: '/pages/index/index'
						}) */
						uni.showToast({
							title:'已提交申请，请等待~',
							icon:'none'
						})
						this.submit = false
						return
					} else {
						uni.showToast({
							title:res_claim.data.msg,
							icon:'none'
						})
						return
					}
				})
				
			}
		}
	}
</script>

<style>
	.banner {
		width: 100%;
	}
	.name_hz {
		display: flex;
		align-items: center;
		padding: 20rpx;
		border-bottom: 1px solid #ececec;
		margin: 0 20rpx;
	}

	.name_hz input {
		padding: 10rpx 20rpx;
		flex: 1;
		border: none;
	}

	.name_hz:nth-of-type(3) {
		padding: 30rpx 20rpx;
	}

	.name_hz label {
		margin-right: 20rpx;
	}
	.determine {
	    padding-top: 10px;
	    display: flex;
	    align-items: center;
	    justify-content: center;
	}
	.btn{
		width: 80%;
		font-size: 30rpx;
		line-height: 70rpx;
		background-color: #f4371e;
		color: #fff;
	}

</style>
