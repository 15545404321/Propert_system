<template>
	<view>
		<!-- 背景 -->
		<image class="banner" :src="admanage_pic" mode="widthFix"></image>
		<!-- 背景结束 -->
		
		<view class="box">
			<!-- 搜索 -->
			<view class="search">
				<input class="text" type="text" placeholder="请输入关键词" v-model="seach">
				<view class="search_right">
					<!-- <input class="submit" type="submit" value="搜索"> -->
					<view class="submit" @click="seach_s()">
						搜索
					</view>
					<view class="line">
					
					</view>
					<view class="cancellation" @click="bxInfo()">
						取消
					</view>
				</view>
				
				<!-- <image class="sea" src="/static/image/seach.png" mode=""></image> -->
			</view>
			<!-- 搜索结束 -->
			
			<!-- 信息部分 -->
			<template v-for="v in list">
				<view class="content">
					<view class="top_text">
						{{v.bmdh_title}}
					</view>
					<view class="project">
						便民项目：
						<view class="price">
							{{v.bmdh_neirong}}
						</view>
					</view>
					
					<view class="phones">
						<view class="name">
							联系人：
							<view class="price">
								{{v.bmdh_lxr}}
							</view>
						</view>
						<image class="teles" src="/static/image/tels.png" mode=""></image>
					</view>
				</view>
			</template>
			<!-- 信息部分结束 -->
			
			
		</view>
		<view style="font-size: 26rpx;color:#999;text-align: center;" v-if="show">没有更多数据</view>
	</view>
</template>

<script>
	import { ConTel ,AdManage} from '../../common/api';
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
				list:[],
				pages:1,
				seach : '', // 搜索内容
				show:false, // 判断是否显示
				admanage_pic : '', // 图片
			}
		},
		onLoad(options) {
			this.getList(JSON.stringify(options))
			let obj = {
				page_type : 'phone',
				shop_id : Cache.get('shop_id')
			}
			AdManage(obj)
			.then(res=>{
				this.admanage_pic = res.data.data.top.admanage_pic
			})
		},
		methods: {
			// 获取列表
			getList(extra){
				let data = {
					extra,
					// pages : this.pages,
					text : '', // 搜索内容
					type : 0, // 0 1 2 3 4
					xqgl_id : Cache.get('xqgl_id'),
					shop_id : Cache.get('shop_id')
				}
				ConTel(data)
				.then(res=>{
					this.list = res.data.data
				})
			},
			seach_s(){
				let data = {
					// pages : this.pages,
					text : this.seach, // 搜索内容
					type : 0, // 0 1 2 3 4
					xqgl_id : Cache.get('xqgl_id'),
					shop_id : Cache.get('shop_id')
				}
				ConTel(data)
				.then(res=>{
					if( res.data.data.length == 0 ){
						this.list = res.data.data
						this.show = true
					}else {
						this.list = res.data.data
						this.show = false
						this.seach = ""
					}
				})
			},
			bxInfo(){
				let data = {
					// pages : this.pages,
					text : '', // 搜索内容
					type : 0, // 0 1 2 3 4
					xqgl_id : Cache.get('xqgl_id'),
					shop_id : Cache.get('shop_id')
				}
				ConTel(data)
				.then(res=>{
					this.list = res.data.data
					this.seach = ""
				})
			}
			
		},
		// 触底的事件
		// onReachBottom() {
		// 	this.pages++
		// 	this.getList()
		// },
	}
</script>

<style>
	body {
		background-color: #ededed;
	}
	.box {
		margin: 20rpx;
	}
	/* 背景 */
	.banner {
		width: 100%;
	}
	/* 背景结束 */
	/* 搜索 */
	.search {
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 20rpx;
		background-color: #fff;
		border-radius: 10rpx;
	}
	.search input {
		flex: 1;
		margin-right: 20rpx;
	}
	.text {
		font-size: 24rpx;
		margin-left: 10rpx;
		color: 7f7f7f;
	}
	.search_right {
		display: flex;
		align-items: center;
	}
	.submit {
		font-size: 24rpx;
		color: #7f7f7f;
	}
	.line {
		border: #d3d3d3 solid 1rpx;
		height: 30rpx;
		margin: 2rpx 10rpx 0;
	}
	.cancellation {
		font-size: 24rpx;
		color: #d3d3d3;
	}
	.sea {
		position: absolute;
		width: 30rpx;
		height: 30rpx;
	}
	/* 搜索结束 */
	/* 信息部分 */
	.content {
		background-color: #fff;
		padding: 25rpx;
		margin-top: 20rpx;
		border-radius: 10rpx;
	}
	.top_text {
		font-size: 30rpx;
		font-weight: 600;
		color: #535353;
	}
	.project {
		display: flex;
		align-items: center;
		background-color: #f6f6f6;
		font-size: 26rpx;
		color: #6d6d6d;
		padding: 10rpx;
		border-radius: 10rpx;
		margin: 10rpx 0;
	}
	.phones {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.name {
		display: flex;
		align-items: center;
		font-size: 26rpx;
		color: #6d6d6d;
	}
	.teles {
		width: 60rpx;
		height: 60rpx;
	}
	/* 信息部分结束 */
</style>
