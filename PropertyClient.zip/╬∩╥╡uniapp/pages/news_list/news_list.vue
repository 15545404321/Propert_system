<template>
	<view>
		<image class="banner" src="/static/image/header.png" mode="widthFix"></image>

		<view class="box">
			<view class="hot">
				<image src="/static/image/news.png" mode=""></image>
			</view>

			<!-- 内容 -->
			<view class="content_box">
				<template v-for="(v,index) in list">
					<view class="content" @click="bxInfo(v.wzgl_id)">
						<view class="content_left">
							<view class="content_top">
								<image src="/static/image/book.png" mode=""></image>
								<view class="top_p el">
									{{v.wzgl_title}}
								</view>
							</view>
							<view class="name">
								<view class="name_text">
									{{v.wzgl_futitle}}
								</view>
							</view>
							<view class="times">
								{{v.wzgl_time}}
							</view>
						</view>
						<view class="picture">
							<image :src="v.wzgl_img" mode="widthFix"></image>
							<image v-if="v.wzgl_img == '' || v.wzgl_img == null" src="../../static/image/wutu.png" mode="widthFix"></image>
						</view>
					</view>
				</template>
			
				
			</view>
			<!-- 内容结束 -->








		</view>
	</view>
</template>

<script>
	import { wyNewsList } from '../../common/api';
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
				list:[],
				pages:1,
				extra:''
			}
		},
		onLoad(options) {
			this.extra = JSON.stringify(options)
			this.getList()
		},
		methods: {
			// 获取列表
			getList(){
				let data = {
					extra: this.extra,
					pages : this.pages,
					shop_id : Cache.get('shop_id'),
				}
				wyNewsList(data)
				.then(res=>{
					this.list = [...this.list, ...res.data.data]
				})
			},
			bxInfo(__id){
				uni.navigateTo({
					url:'/pages/news_detail/news_detail?wzgl_id=' + __id
				})
			}
		},
		// 触底的事件
		onReachBottom() {
			this.pages++
			this.getList()
		},
	}
</script>

<style>
	body {
		background-color: #ededed;
	}

	.box {
		margin: 15rpx;
	}

	.banner {
		width: 100%;
	}


	.hot {
		background-color: #fff;
		border-radius: 10rpx;
		padding: 20rpx 20rpx 10rpx;
		margin-bottom: 20rpx;
	}

	.hot image {
		width: 180rpx;
		height: 35rpx;
	}

	/* 内容 */
	.content_box {
		background-color: #fff;
		border-radius: 10rpx;
		padding: 10rpx 20rpx;
	}
	.content {
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-bottom: solid 2rpx #ededed;
		padding: 20rpx;
	}
	.content:last-child{
		border: none;
	}
	.content_top {
		display: flex;
		align-items: center;
	}

	.content_top image {
		width: 45rpx;
		height: 45rpx;
	}

	.top_p {
		font-size: 28rpx;
		font-weight: 600;
		margin-left: 10rpx;
	}

	.name {
		display: flex;
		align-items: center;
		font-size: 26rpx;
		color: #747474;
		margin: 20rpx 0;
	}

	.times {
		font-size: 26rpx;
		color: #747474;
	}

	.picture image {
		width: 140rpx;
		height: 140rpx;
	}

	/* 内容结束 */
</style>
