<template>
	<view class="whole">
		<!-- 背景 -->
		<image class="banner" :src="admanage_pic_top" mode="widthFix"></image>

		<!-- 导航栏 -->
		<view class="nav">

			<view class="nav_box" @click="report()">
				<view class="nav_img">
					<image src="/static/image/my/wybx.png" mode=""></image>
				</view>
				<view class="nav_p">
					物业维修
				</view>
			</view>

			<view class="nav_box" @click="query()">
				<view class="nav_img">
					<image src="/static/image/my/money.png" mode=""></image>
				</view>
				<view class="nav_p">
					缴费查询
				</view>
			</view>

			<view class="nav_box" @click="phone()">
				<view class="nav_img">
					<image src="/static/image/my/tel.png" mode=""></image>
				</view>
				<view class="nav_p">
					便民电话
				</view>
			</view>

			<view class="nav_box" @click="mask()">
				<view class="nav_img">
					<image src="/static/image/my/tsjy.png" mode=""></image>
				</view>
				<view class="nav_p">
					投诉建议
				</view>
			</view>

		</view>
		<!-- 导航栏结束 -->

		<!-- 智能物业 -->
		<image class="banner2" :src="admanage_pic_middle" mode="widthFix"></image>
		<!-- 智能物业结束 -->

		<!-- 查询 -->
		<view class="bottom">

			<view class="bottoms" @click="cost()">
				<view class="bottom_left">
					<image src="/static/image/my/jfcx.png" mode="widthFix"></image>
					<view class="bottom_p">
						费用查询
					</view>
				</view>
				<image class="jian" src="/static/image/my/jiantou.png" mode="widthFix"></image>
			</view>

			<view class="bottoms" @click="repair()">
				<view class="bottom_left">
					<image src="/static/image/my/bxd.png" mode="widthFix"></image>
					<view class="bottom_p">
						报修查询
					</view>
				</view>
				<image class="jian" src="/static/image/my/jiantou.png" mode="widthFix"></image>
			</view>

			<view class="bottoms" @click="confirmShare()">
				<view class="bottom_left">
					<!-- /static/ima/houses.png -->
					<image src="../../static/image/my/username.png" mode="widthFix"></image>
					<view class="bottom_p">
						切换小区
					</view>
				</view>
				<image class="jian" src="/static/image/my/jiantou.png" mode="widthFix"></image>
			</view>

		</view>
		<!-- 查询结束 -->
		<view v-if="showMask" class="login_text" @click="hideMask()"></view>
		<view v-if="showMask" class="login">
			<view class="banners">
				<image src="/static/image/complaint.png" mode="widthFix"></image>
				<!-- <view class="banners_text"> -->
				<textarea class="banners_text" name="" id="" cols="30" rows="10" placeholder="请描述" v-model="sugg"
					placeholder-style="font-size: 24rpx;"></textarea>
				<!-- </view> -->
				<view class="submit">
					<text @click="clickSubmit()">点击提交</text>
				</view>
			</view>
		</view>

		<view class="share">
			<!-- 弹出背景灰色 -->
			<view :class="{'box': share}" @click="display"></view>
			<!-- 弹出部分 -->
			<view class="share-item" :class="{'show': share}">
				<scroll-view scroll-y="true">
					<view class="spOne">

						<view class="name_hz">
							<view class="zswy">
								<image src="../../static/image/fangzi.jpg" mode="widthFix"></image>
								<view>众森物业</view>
							</view>
							<radio-group @change="handlRadio" class="radioGroup">
								<view class="anniu" v-for="v in quarters">
									<label>
										<radio color="red" :value="v.xqgl_id" :checked="conclusionRadio == v.xqgl_id"  /><text>{{v.xqgl_name}}</text>
									</label>
								</view>
							</radio-group>

						</view>

					</view>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		suggestion,
		getXqglList,
		getShopInfo,
		AdManage
	} from '../../common/api'
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
				showMask: false,
				sugg: '', // 投诉建议
				share: false,
				quarters:[],
				shop_name: '',
				conclusionRadio:Cache.get('xqgl_id'),
				admanage_pic_top : '',
				admanage_pic_middle : ''
			}
		},
		onLoad() {
			let obj = {
				shop_id: Cache.get('shop_id')
			}
			getXqglList(obj)
			.then(res=>{
				this.quarters = res.data.data
			})
			// getShopInfo().then( res => {
			// 	console.log(res)
			// 	// this.shop_name = 
			// })
			let data = {
				page_type : 'mycenter',
				shop_id : Cache.get('shop_id')
			}
			AdManage(data)
			.then(res=>{
				this.admanage_pic_top = res.data.data.top.admanage_pic
				this.admanage_pic_middle = res.data.data.middle.admanage_pic
			})
		},
		methods: {
			// 单选框
			handlRadio(e) {
				this.radioValue = e.detail.value
				this.conclusionRadio = e.detail.value
				this.share = false
				// console.log(e.detail.value);
				Cache.set('xqgl_id',e.detail.value)
				// window.location.href = 'http://wyqt.jf.ivimoo.com/mobile/#/pages/user/user'
				// window.location.replace('http://wyqt.jf.ivimoo.com/mobile/#/pages/user/user')
				window.history.replaceState(null, "", 'http://wyqt.jf.ivimoo.com/mobile/#/pages/user/user');
				window.history.go(0);
				// uni.clearStorageSync()
			},
			mask() {
				this.showMask = true
			},
			hideMask() {
				this.showMask = false
			},
			clickSubmit() {
				if (this.sugg == '') {
					uni.showToast({
						title: '请输入投诉意见',
						icon: 'none'
					})
					return
				}
				let data = {
					shop_id: Cache.get('shop_id'),
					tsjy_tsnr: this.sugg
				}
				suggestion(data)
					.then(res => {
						uni.showToast({
							title: '提交成功!',
							icon: 'none'
						})
						this.showMask = false
						this.sugg = ''
					})
			},
			confirmShare() {
				this.share = true;
			},
			// 隐藏分享
			display() {
				this.share = false;
			},
			// 报修列表
			repair(){
				uni.navigateTo({
					url:'/pages/repair/repair'
				})
			},
			// 费用查询
			cost(){
				uni.navigateTo({
					url:'/pages/cost/cost'
				})
			},
			// 缴费查询
			query(){
				uni.navigateTo({
					url:'/pages/arrears_list/arrears_list'
				})
			},
			// 物业报修
			report(){
				uni.navigateTo({
					url:'/pages/apply/apply'
				})
			},
			// 便民电话
			phone(){
				uni.switchTab({
					url:'/pages/phone/phone'
				})
			}
		}
	}
</script>

<style>
	body {
		background-color: #ededed;
	}

	.whole {
		margin: 20rpx;
	}

	/* 背景 */
	.banner {
		width: 100%;
		border-radius: 10rpx;
	}

	/* 背景结束 */
	/* 导航栏 */
	.nav {
		display: flex;
		align-items: center;
		justify-content: space-around;
		background-color: #fff;
		margin-top: 10rpx;
		padding: 20rpx 16rpx;
		border-radius: 10rpx;
	}

	.nav_box {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.nav_img image {
		width: 60rpx;
		height: 60rpx;
	}

	.nav_p {
		font-size: 24rpx;
		font-weight: 600;
	}

	/* 导航栏结束 */
	/* 智能物业图片 */
	.banner2 {
		width: 100%;
		margin-top: 20rpx;
	}

	/* 智能物业图片结束 */
	/* 查询 */
	.bottom {
		background-color: #fff;
		padding: 20rpx 20rpx 40rpx 20rpx;
		border-radius: 10rpx;
	}

	.bottoms {
		display: flex;
		align-items: center;
		justify-content: space-between;
		border-bottom: solid 2rpx #ededed;
		padding: 20rpx;
	}

	.bottom_left {
		display: flex;
		align-items: center;
	}

	.bottom_left image {
		width: 40rpx;
		height: 40rpx;
		margin-left: 10rpx;
	}

	.bottom_p {
		font-size: 28rpx;
		font-weight: 600;
		margin-left: 10rpx;
	}

	.jian {
		width: 30rpx;
		height: 30rpx;
	}

	/* 查询结束 */

	.login_text {
		position: fixed;
		/* width: 100%; */
		/* height: 100%; */
		top: 0;
		bottom: 0;
		right: 0;
		left: 0;
		background-color: rgba(0, 0, 0, .3);
		z-index: 9;
		cursor: pointer;
	}

	.login {
		position: absolute;
		top: 20%;
		left: 0%;
		z-index: 99;
	}

	.banners {
		position: relative;
	}

	.banners image {
		width: 800rpx;
	}

	.banners_text {
		position: absolute;
		top: 37%;
		left: 28%;
		width: 300rpx;
		max-height: 210rpx;
	}

	.submit {
		display: flex;
		justify-content: center;
		width: 100%;
		position: absolute;
		bottom: 17%;
		left: -22rpx;
		text-align: center;
		line-height: 80rpx;
	}

	.submit text {
		display: inline-block;
		width: 40%;
		background-color: #fb5255;
		border-radius: 50rpx;
		font-weight: 600;
		color: #fff;
	}










	/* 弹窗 */
	.main {
		width: 100%;
		height: 2000rpx;
		background: #007AFF;
	}

	.share {
		width: 100%;
		height: 100%;
		position: relative;
	}

	.box {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0rpx;
		left: 0rpx;
		bottom: 0rpx;
		right: 0rpx;
		background-color: rgba(0, 0, 0, 0.4);
		transition: .3s;
		z-index: 999;
	}

	.show {
		transition: all 0.3s ease;
		transform: translateY(0%) !important;
	}

	.share-item {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		height: 1000rpx;
		background-color: #FFFFFF;
		transition: all 0.3s ease;
		transform: translateY(100%);
		z-index: 999;
		border-radius: 50rpx 50rpx 0 0;
	}

	/* 内容 */
	.zswy {
		padding: 40rpx 25rpx 20rpx;
		margin: 0 20rpx;
		display: flex;
		align-items: center;
		border-bottom: 2rpx solid #f1f1f1;

	}

	.zswy image {
		width: 8%;
		margin-right: 10rpx;
	}

	.radioGroup {
		margin-left: 20rpx;
		margin-top: 20rpx;
		padding: 10rpx 30rpx;
	}
	.anniu {
		margin-bottom: 20rpx;
	}
	.anniu label {
		display: flex;
		align-items: center;
	}
	.anniu /deep/ uni-radio .uni-radio-input {
		width: 40rpx !important;
		height: 40rpx !important;
	}
</style>
