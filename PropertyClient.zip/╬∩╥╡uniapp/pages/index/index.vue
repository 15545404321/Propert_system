<template>
	<view class="content">
		<!-- 顶部背景 -->
		<image class="banner" mode="widthFix" :src="background"></image>
		<!-- 顶部背景结束 -->
		<view class="big_box">
			<!-- 四个导航栏 -->
			<view class="nav">
				<view class="nav_box" v-for="item in navArr" @click="goPage(item.position,item.page)">
					<view class="nav_imgs">
						<image :src="item.url" mode="widthFix"></image>
					</view>
					<view class="p">{{item.title}}</view>
				</view>
				
				<!-- <view class="nav_box" @click="goPage('/pages/news_list/news_list',2)">
					<view class="nav_imgs">
						<image src="/static/image/sy_tp/sytb/gntb2.png" mode="widthFix"></image>
					</view>
					<view class="p">物业新闻</view>
				</view>
				<view class="nav_box" @click="goPage('/pages/recruit_list/recruit_list',2)">
					<view class="nav_imgs">
						<image src="/static/image/sy_tp/sytb/gntb3.png" mode="widthFix"></image>
					</view>
					<view class="p">招聘信息</view>
				</view>
				<view class="nav_box"  @click="mask()" >
					<view class="nav_imgs">
						<image src="/static/image/sy_tp/sytb/gntb4.png" mode="widthFix"></image>
					</view>
					<view class="p">投诉建议</view>
				</view> -->
			</view>
			<!-- 四个导航栏结束 -->

			<!-- 三大块 -->
			<view class="three">
				<view class="three_box" v-for="item in threeArr">
					<view class="three_p" @click="goPage(item.position,item.page)">
						<!-- 物业<br> -->
						<!-- 报修 -->
						<view>{{item['titlees'][0]}}</view>
						<view>{{item['titlees'][1]}}</view>
					</view>
					<view class="three_img">
						<image :src="item.url" mode=""></image>
					</view>
				</view>
				<!-- <view class="three_box">
					<view class="three_p" @click="goPage('/pages/arrears_list/arrears_list',2)">
						缴费<br>
						查询
					</view>
					<view class="three_img">
						<image src="/static/image/sy_tp/sy_zxjf.png" mode=""></image>
					</view>
				</view>
				<view class="three_box">
					<view class="three_p" @click="goPage('/pages/contact_us/contact_us',2)">
						联系<br>
						我们
					</view>
					<view class="three_img">
						<image src="/static/image/sy_tp/sy_kf.png" mode=""></image>
					</view>
				</view> -->
			</view>
			<!-- 三大块结束 -->

			<!-- 热门应用 -->
			<view class="hot">
				<view class="block">
					<image src="/static/image/sy_tp/sy_rm.png" mode=""></image>
				</view>

				<view class="hot_boxs">
					<view v-for="item in applicationArr" class="hot_box" @click="goPage(item.position,item.page)">
						<view class="hot_img">
							<image :src="item.url" mode=""></image>
						</view>
						<view class="hot_p">
							<view class="hot_p1">{{item.title}}</view>
							<view class="hot_p2">{{item.title}}</view>
						</view>
					</view>

					<!-- <view class="hot_box" @click="goPage('/pages/phone/phone?shop_id=1',1)">
						<view class="hot_img">
							<image src="/static/image/sy_tp/sy_jdwx.png" mode=""></image>
						</view>
						<view class="hot_p">
							<view class="hot_p1">家电维修</view>
							<view class="hot_p2">专业技工上门</view>
						</view>
					</view>
					<view class="hot_box" @click="goPage('/pages/phone/phone?shop_id=1',1)">
						<view class="hot_img">
							<image src="/static/image/sy_tp/sy_bm.png" mode=""></image>
						</view>
						<view class="hot_p">
							<view class="hot_p1">保姆月嫂</view>
							<view class="hot_p2">照料家务起居</view>
						</view>
					</view>
				
					<view class="hot_box" @click="goPage('/pages/phone/phone?shop_id=1',1)">
						<view class="hot_img">
							<image src="/static/image/sy_tp/sy_ks.png" mode=""></image>
						</view>
						<view class="hot_p">
							<view class="hot_p1">开锁换锁</view>
							<view class="hot_p2">公安备案，快捷安全</view>
						</view>
					</view>
 -->				</view>

				
			</view>
			<!-- 热门应用结束 -->
			<image  @click="goPage('/pages/apply/apply',2)" class="banner ed" mode="widthFix" :src="ad_img"></image>
		</view>
		
		<view v-if="showMask" class="login_text" @click="hideMask()"></view>
		<view v-if="showMask" class="login">
			<view class="banners">
				<image src="/static/image/complaint.png" mode="widthFix"></image>
				<!-- <view class="banners_text"> -->
				<textarea class="banners_text" name="" id="" cols="30" rows="10" placeholder="请描述" v-model="sugg" placeholder-style="font-size: 24rpx;"></textarea>
				<!-- </view> -->
				<view class="submit">
					<text @click="clickSubmit()">点击提交</text>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	import { indexLive, suggestion } from '../../common/api'
	import Cache from '@/utils/cache'
	export default {
		data() {
			return {
				showMask: false,
				sugg : '' , // 投诉建议
				background : '', // 图片
				navArr :[], // 四个导航
				threeArr : [], // 三块
				applicationArr : [] ,// 热门应用
				ad_img : '' // 底部图片
			}
		},
		onLoad() {
			let that = this
			// uni.request({
			// 	url:'http://cgflxx.yooshu.net/api/index/index',
			// 	method:'GET',
			// 	success(res){
			// 		console.log(res);
			// 		that.arr = res.data.data
			// 		that.background = res.data.data.background // 第一个背景
			// 		that.navArr = res.data.data.nav // 中间四个导航
			// 		res.data.data.three.map(v=>{
			// 			let l = v.title[0]+v.title[1]
			// 			let r = v.title[2]+v.title[3]
			// 			let resLR = l + '-' + r
			// 			v['titlees'] = resLR.split('-')
			// 		})
			// 		that.threeArr = res.data.data.three // 三块
			// 		that.applicationArr = res.data.data.application // 热门应用
			// 		that.ad_img = res.data.data.ad_img.url // 底部图片
			// 	}
			// })
			indexLive({shop_id : Cache.get('shop_id')})
			.then(res=>{ 
				console.log(res.data.data);
				that.arr = res.data.data
				that.background = res.data.data.background // 第一个背景
				that.navArr = res.data.data.nav // 中间四个导航
				// that.navArr.map(v=>{
				// 	v.maps.map(vMaps=>{
				// 		console.log(vMaps);
						
				// 	})
				// })
				res.data.data.three.map(v=>{
					let l = v.title[0]+v.title[1]
					let r = v.title[2]+v.title[3]
					let resLR = l + '-' + r
					v['titlees'] = resLR.split('-')
				})
				that.threeArr = res.data.data.three // 三块
				that.applicationArr = res.data.data.application // 热门应用
				that.ad_img = res.data.data.ad_img.url // 底部图片
			})
		},
		methods: {
			goPage(path,type,_item) {
				// console.log(path);return
				if (type == 1) {
					uni.reLaunch({
						url: path
					})
				}else if(type == 3){
					this.mask()
				} else {
					uni.navigateTo({
						url: path
					})
				}
			},
			mask() {
				this.showMask = true
			},
			hideMask() {
				this.showMask = false
			},
			clickSubmit(){
				if( this.sugg == '' ){
					uni.showToast({
						title:'请输入投诉意见',
						icon:'none'
					})
					return
				}
				let data = {
					shop_id : Cache.get('shop_id'),
					tsjy_tsnr : this.sugg
				}
				suggestion(data)
				.then(res=>{
					uni.showToast({
						title:'提交成功!',
						icon:'none'
					})
					this.showMask = false
					this.sugg = ''
				})
			}
		}
	}
</script>

<style>
	body {
		background-color: #ededed;
	}

	/* 顶部背景 */
	.banner {
		width: 100%;
	}

	/* 顶部背景结束 */

	/* 四个导航栏 */
	.big_box {
		position: relative;
		top: -65rpx;
		margin: 0 20rpx;
	}

	.big_box {}

	.nav {
		display: flex;
		/* justify-content: space-around; */
		flex-wrap: wrap;
		background-color: #fff;
		padding: 20rpx 16rpx;
		border-radius: 10rpx;
	}

	.nav_box {
		width: 25%;
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-bottom: 20rpx;
	}
	.nav_box:nth-last-child(1){
		margin-bottom: 0;
	}
	.nav_box:nth-last-child(2){
		margin-bottom: 0;
	}
	.nav_box:nth-last-child(3){
		margin-bottom: 0;
	}
	.nav_box:nth-last-child(4){
		margin-bottom: 0;
	}

	.nav_imgs image {
		width: 90rpx;
	}

	.p {
		font-size: 24rpx;
	}

	/* 四个导航栏结束 */

	/* 三个服务 */
	.three {
		display: flex;
		align-items: center;
		/* justify-content: space-between; */
		flex-wrap: wrap;
	}

	.three_box {
		width: 27.5%;
		border-radius: 10rpx;
		padding: 14rpx;
		margin-right: 20rpx;
		margin-top: 20rpx;
	}
	.three_box:nth-of-type(3n-2){
		background-color: #ff9d52;
	}
	.three_box:nth-child(3n-1) {
		background-color: #40a5ff;
	}

	.three_box:nth-child(3n) {
		background-color: #ffc53d;
		margin-right: 0;
	}
	
	/* .three_box:nth-last-child(1){
		margin-bottom: 0;
	}
	.three_box:nth-last-child(2){
		margin-bottom: 0;
	}
	.three_box:nth-last-child(3){
		margin-bottom: 0;
	}
 */
	.three_p {
		font-size: 24rpx;
		color: #fff;
	}

	.three_img {
		display: flex;
		justify-content: flex-end;
	}

	.three_img image {
		width: 60rpx;
		height: 60rpx;
	}

	/* 三个服务结束 */
	/* 热门应用 */
	.hot {
		background-color: #fff;
		padding: 20rpx;
		margin-top: 20rpx;
		border-radius: 10rpx;
	}

	.block image {
		width: 200rpx;
		height: 50rpx;
		margin-left: 20rpx;

	}

	.hot_boxs {
		display: flex;
		flex-wrap: wrap;
	}

	.hot_box {
		display: flex;
		align-items: center;
		border: solid 2rpx #ededed;
		padding: 10rpx;
		width: 45.5%;
		border-radius: 10rpx;
		margin-right: 10rpx;
		margin-top: 10rpx;
	}
	.hot_box:nth-of-type(4n-3) {
		color: #d8513b;
	}
	.hot_box:nth-of-type(4n-2) {
		color: #3bb4d1;
	}
	.hot_box:nth-of-type(4n-1) {
		color: #6c82b1;
	}
	.hot_box:nth-of-type(4n) {
		color: #dcb148;
	}
	.hot_box:nth-of-type(2n){
		margin-right: 0;
	}

	.hot_img image {
		width: 110rpx;
		height: 110rpx;
	}

	.hot_p {
		margin-left: 20rpx;
		font-size: 24rpx;
	}
	.hot_p2 {
		color: #afafb1;
	}


	/* .a2 {
		color: #3bb4d1 !important;
	}

	.hot_p1.a3 {
		color: #6c82b1 !important;
	}

	.hot_p1.a4 {
		color: #dcb148 !important;
	}

	.hot_p2 {
		color: #afafb1;
	} */

	/* 热门应用结束 */
	.banner.ed {
		margin-top: 20rpx;
		border-radius: 10rpx;
	}

	/* 遮罩背景 */
	.login_text {
		position: fixed;
		top: 0;
		bottom: 0;
		right: 0;
		left: 0;
		background-color: rgba(0, 0, 0, .3);
		z-index: 9;
		cursor: pointer;
	}
	.login {
		position: absolute;
		top: 20%;
		left: 0%;
		z-index: 99;
	}
	.banners {
		position: relative;
	}
	.banners image {
		width: 800rpx;
	}
	.banners_text {
		position: absolute;
		top: 37%;
		left: 28%;
		width: 300rpx;
		max-height: 210rpx;
	}
	.submit {
		display: flex;
		justify-content: center;
		width: 100%;
		position: absolute;
		bottom: 17%;
		left: -22rpx;
		text-align: center;
		line-height: 80rpx;
	}
	.submit text {
		display: inline-block;
		width: 40%;
		background-color: #fb5255;
		border-radius: 50rpx;
		font-weight: 600;
		color: #fff;
	} 
	/* 


	.banners_text {
		position: absolute;
		top: 37%;
		left: 28%;
	}
	.banners_text textarea {
		width: 350rpx;
		font-size: 24rpx;
	}
	
	.submit {
		display: flex;
		justify-content: center;
		width: 100%;
		position: absolute;
		bottom: 20%;
		text-align: center;
		line-height: 80rpx;
	}
	.submit text {
		display: inline-block;
		width: 350rpx;
		background-color: #fb5255;
		border-radius: 50rpx;
		font-weight: 600;
		color: #fff;
	} */
</style>
