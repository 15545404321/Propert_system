<template>
	<view>
		<!-- 背景 -->
		<image class="banner" src="/static/image/header.png" mode="widthFix"></image>
		<!-- 背景结束 -->
		<!-- 内容 -->
		<view class="box">
			<!-- 标题 -->
			<view class="h1">
				{{bxxx_miaoshu}}
			</view>
			<!-- 标题结束 -->
			<!-- 时间 -->
			<view class="h6">
				<view class="date">
					{{bxxx_time}}
				</view>
			</view>
			<!-- 时间结束 -->
			<!-- 内容文本 -->
			<view class="detail">
				<view class="h3">
					处理反馈：{{bxxx_fankui}}
				</view>
				<view class="text">
					为了给业主创造一个优美、舒适、安全、文明的居住环境。众森物业不断提升管理服务水平，体现专业化管理、标准化服务的管理理念，本着以匠心深耕服务的每一个细节为业主服务!现将第二季度的物业服务工作报告呈现给您，以便您能够较全面地了解物业服务工作，敬请您提出宝贵意见。
				</view>
				<view class="h4">
					具体报告内容如下：
				</view>
				<!-- 内容文本结束 -->
				<!-- 内容图片 -->
				<view class="images">
					<image v-for="v in bxxx_pic" :src="v" mode="widthFix"></image>
				</view>
				<!-- 内容图片结束 -->
				
				
			</view>
		</view>
		<!-- 内容结束 -->

	</view>
</template>

<script>
	
	import Cache from '@/utils/cache'
	import { ReportInfo } from '../../common/api';
	export default {
		data() {
			return {
				bxxx_miaoshu : '',
				bxxx_time : '',
				bxxx_fankui : '',
				bxxx_pic : [],
			}
		},
		onLoad(options) {
			const shop_id = Cache.get('shop_id');
			let obj = {
				shop_id,
				bxxx_id : options.bxxx_id
			}
			ReportInfo(obj)
			.then(res=>{
				console.log(res);
				this.bxxx_miaoshu = res.data.data.bxxx_miaoshu
				this.bxxx_time = res.data.data.bxxx_time
				this.bxxx_fankui = res.data.data.bxxx_fankui
				this.bxxx_pic = res.data.data.bxxx_pic
				
			})
		},
		methods: {
			
		}
	}
</script>

<style>
	/* 背景 */
	.banner {
		width: 100%;
	}

	/* 内容 */
	.box {
		background-color: #fff;
		margin: 20rpx;
		padding: 30rpx;
	}

	/* 标题 */
	.h1 {
		font-size: 32rpx;
		font-weight: 600;
		/* display: -webkit-box;
		text-overflow: ellipsis;
		overflow: hidden;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 1; */
		margin: 20rpx 0;
	}

	/* 标题结束 */
	/* 时间 */
	.h6 {
		display: flex;
		font-size: 26rpx;
		color: #c1c1c1;
		margin: 20rpx 0;
	}

	/* 时间结束 */
	/* 内容文本 */
	.detail {
		background-color: #fffcf1;
		border: #fea01a 2rpx dashed;
		padding: 30rpx;
		border-radius: 10rpx;
		font-size: 28rpx;
		line-height: 45rpx;
		color: #303030;
		text-align: justify;
		text-align-last: left;
		margin-top: 30rpx;
	}
	.h3 {
		margin: 10rpx 0;
	}
	/* 内容文本结束 */
	/* 内容图片 */
	.images {
		margin: 20rpx 0;
	}
	.images image {
		width: 30%;
		margin: 0 10rpx;
	}
	/* 内容图片结束 */
	
	/* 内容结束 */
</style>
