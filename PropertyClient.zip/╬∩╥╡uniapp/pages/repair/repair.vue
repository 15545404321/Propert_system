<template>
	<view class="con">
		<view class="container">
			<view class="box">
				<view class="inv-h-w">
					<view :class="['inv-h',Inv==0?'inv-h-se1':'']" @click="byInv(0)">全部保修单</view>
					<view :class="['inv-h',Inv==1?'inv-h-se':'']" @click="byInv(1)">未完成</view>
					<view :class="['inv-h',Inv==2?'inv-h-se':'']" @click="byInv(2)">已完成</view>
				</view>
				<!-- 第一个标签栏 -->
				<view class="content1" v-show="Inv == 0">
					<template v-for="v in list">
						<view class="list">
							<view class="task">
								<view class="TaskName">{{v.bxxx_miaoshu}}</view>
								<view class="states" v-if="v.bxxx_start == 1 || v.bxxx_start == 3 ">未完成</view>
								<view class="state" v-if="v.bxxx_start == 2">已完成</view>
							</view>
							
							<view class="MasterName">
								<view class="master">工程师傅</view>
								<view class="name">{{v.cname}}</view>
							</view>
							<view class="time">{{v.bxxx_cltime}}</view>
						</view>
					</template>
				</view>
				<!-- 第一个标签栏结束 -->
				<!-- 第二个标签栏 -->
				<view class="content2" v-show="Inv == 1">
					<template v-for="v in list">
						<view class="list">
							<view class="task">
								<view class="TaskName">{{v.bxxx_miaoshu}}</view>
								<view class="states" v-if="v.bxxx_start == 1 || v.bxxx_start == 3 ">未完成</view>
							</view>
							
							<view class="MasterName">
								<view class="master">工程师傅</view>
								<view class="name">{{v.cname}}</view>
							</view>
							<view class="time">{{v.bxxx_cltime}}</view>
						</view>
					</template>
				</view>
				<!-- 第二个标签栏结束 -->
				<!-- 第三个标签栏 -->
				<view class="content3" v-show="Inv == 2">
					<template v-for="v in list">
						<view class="list">
							<view class="task">
								<view class="TaskName">{{v.bxxx_miaoshu}}</view>
								<view class="state">已完成</view>
							</view>
							
							<view class="MasterName">
								<view class="master">工程师傅</view>
								<view class="name">{{v.cname}}</view>
							</view>
							<view class="time">{{v.bxxx_cltime}}</view>
						</view>
					</template>
				</view>
				<!-- 第三个标签栏结束 -->
			</view>
		</view>
	</view>
</template>

<script>
	import Cache from '@/utils/cache'
	import { repairSearch } from '../../common/api';
	export default {
		data() {
			return {
				Inv: 0,
				pages : 1,
				list:[]
			}
		},
		onLoad() {
			this.infoList()
		},
		methods: {
			// type = 1 未完成  type = 2 已完成
			infoList(status=0){
				const shop_id = Cache.get('shop_id');
				let obj = {
					pages : this.pages,
					shop_id,
					type : status
				}
				repairSearch(obj)
				.then(res=>{
					this.list = [...this.list, ...res.data.data]
				})
			},
			byInv(v) {
				this.Inv = v
				this.list = []
				this.pages = 1
				if( v == 0 ){
					this.infoList(0)
				}else if( v == 1 ){
					this.infoList(1)
				}else if( v == 2 ){
					this.infoList(2)
				}
			}
		},
		// 触底的事件
		onReachBottom() {
			this.pages++
			if( this.Inv == 0 ){
				this.infoList(0)
			}else if( this.Inv == 1 ){
				this.infoList(1)
			}else if( this.Inv == 2 ){
				this.infoList(2)
			}
		},
	}
</script>

<style>
	.inv-h-w {
		display: flex;
		justify-content: space-around;
		align-items: center;
		background-color: #fff;
		color: #636363;
		font-size: 26rpx;
		font-weight: 600;
		padding: 20rpx 0;
	}
	.content1 {
		margin: 20rpx;
	}
	.content2 {
		margin: 20rpx;
	}
	.content3 {
		margin: 20rpx;
	}
	.inv-h-se {
		position: relative;
		color: #000;
	}
	.inv-h-se1 {
		position: relative;
		color: #000;
	}
	.inv-h-se1::before {
		content: '';
		position: absolute;
		width: 50%;
		height: 5rpx;
		background-color: #ec0c24;
		bottom: -20rpx;
		left: 25%;
		border-radius: 10rpx;
	}
	.inv-h-se::before {
		content: '';
		position: absolute;
		width: 80%;
		height: 5rpx;
		background-color: #ec0c24;
		bottom: -20rpx;
		left: 10%;
		border-radius: 10rpx;
	}
	/* 第一个便签栏 */
	.list {
		background-color: #fff;
		padding: 20rpx 30rpx;
		border-radius: 10rpx;
		font-size: 25rpx;
		color: #9b9b9b;
		/* font-weight: 600; */
		margin-bottom: 20rpx;
	}
	.task {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.MasterName {
		display: flex;
		align-items: center;
		margin: 15rpx 0;
	}
	.MasterName .name {
		margin-left: 40rpx;
	}
	.states {
		color: #c54752;
	}
	/* 第一个便签栏结束 */
</style>
