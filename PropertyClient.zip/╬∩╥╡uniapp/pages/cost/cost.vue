<template>
	<view class="con">
		<view class="container">
			<view class="box">
				<view class="inv-h-w">
					<view :class="['inv-h',Inv==0?'inv-h-se':'']" @click="byInv(0)">未付款</view>
					<view :class="['inv-h',Inv==1?'inv-h-se':'']" @click="byInv(1)">已付款</view>
					<view :class="['inv-h',Inv==2?'inv-h-se':'']" @click="byInv(2)">已退款</view>
					<view :class="['inv-h',Inv==3?'inv-h-se':'']" @click="byInv(3)">转预存</view>
				</view>
				<!-- 第一个标签栏 -->
				<view class="content1" v-show="Inv == 0">
					<template v-for="v in list">
						<view class="list">
							<view class="fist_line">
								<view class="line_left">
									<image v-if="v.fcxx_id != null && v.cbgl_id == null" src="../../static/image/fangzi.png" mode="widthFix"></image>
									<image v-if="v.cewei_id != null"  src="../../static/image/cheliang.png" mode="widthFix"></image>
									<image v-if="v.cbgl_id != null && v.fcxx_id != null" src="../../static/image/yibiao.png" mode="widthFix"></image>
									<view class="Property">{{v.yssj_fymc}}</view>
								</view>
								<view class="states">未付款</view>
							</view>
						
							<view class="two_line">
								<view class="number">资产编号</view>
								<view class="Vertical">|</view>
								<view class="Location">{{v.zcbh}}</view>
							</view>
						
							<view class="three_line">
								<view class="line_left">
									<view class="start">{{v.yssj_kstime}}</view>
									<view class="horizontal">-</view>
									<view class="end">{{v.yssj_jztime}}</view>
								</view>
								<view class="line_right">￥{{v.yssj_ysje}}</view>
							</view>
						
							<!-- <view class="four_line">
								<view class="times">付款状态：</view>
								<view class="states" v-if="v.yssj_stuats == 0">未付款</view>
							</view> -->
						</view>
					</template>
				</view>
				<!-- 第一个标签栏结束 -->
				<!-- 第二个标签栏 -->
				<view class="content2" v-show="Inv == 1">
					<template v-for="v in list">
						<view class="list">
							<view class="fist_line">
								<view class="line_left">
									<image v-if="v.fcxx_id != null && v.cbgl_id == null" src="../../static/image/fangzi.png" mode="widthFix"></image>
									<image v-if="v.cewei_id != null"  src="../../static/image/cheliang.png" mode="widthFix"></image>
									<image v-if="v.cbgl_id != null && v.fcxx_id != null" src="../../static/image/yibiao.png" mode="widthFix"></image>
									<view class="Property">{{v.yssj_fymc}}</view>
								</view>
								<view class="s">已付款</view>
							</view>
						
							<view class="two_line">
								<view class="number">资产编号</view>
								<view class="Vertical">|</view>
								<view class="Location">{{v.zcbh}}</view>
							</view>
						
							<view class="three_line">
								<view class="line_left">
									<view class="start">{{v.yssj_kstime}}</view>
									<view class="horizontal">-</view>
									<view class="end">{{v.yssj_jztime}}</view>
								</view>
								<view class="line_right">￥{{v.yssj_ysje}}</view>
							</view>
						
							<view class="four_line">
								<view class="times">付款时间：</view>
								<view class="s">{{v.yssj_fksj}}</view>
							</view>
						</view>
					</template>
				</view>
				<!-- 第二个标签栏结束 -->
				<!-- 第三个标签栏 -->
				<view class="content3" v-show="Inv == 2">
					<template v-for="v in list">
						<view class="list">
							<view class="fist_line">
								<view class="line_left">
									<image v-if="v.fcxx_id != null && v.cbgl_id == null" src="../../static/image/fangzi.png" mode="widthFix"></image>
									<image v-if="v.cewei_id != null"  src="../../static/image/cheliang.png" mode="widthFix"></image>
									<image v-if="v.cbgl_id != null && v.fcxx_id != null" src="../../static/image/yibiao.png" mode="widthFix"></image>
									<view class="Property">{{v.yssj_fymc}}</view>
								</view>
								<view class="s">已退款</view>
							</view>
						
							<view class="two_line">
								<view class="number">资产编号</view>
								<view class="Vertical">|</view>
								<view class="Location">{{v.zcbh}}</view>
							</view>
						
							<view class="three_line">
								<view class="line_left">
									<view class="start">{{v.yssj_kstime}}</view>
									<view class="horizontal">-</view>
									<view class="end">{{v.yssj_jztime}}</view>
								</view>
								<view class="line_right">￥{{v.yssj_ysje}}</view>
							</view>
						
							<!-- <view class="four_line">
								<view class="times">付款状态：</view>
								<view class="s">已退款</view>
							</view> -->
						</view>
					</template>
				</view>
				<!-- 第三个标签栏结束 -->
				<!-- 第四个标签栏 -->
				<view class="content4" v-show="Inv == 3">
					<template v-for="v in list">
						<view class="list">
							<view class="fist_line">
								<view class="line_left">
									<image v-if="v.fcxx_id != null && v.cbgl_id == null" src="../../static/image/fangzi.png" mode="widthFix"></image>
									<image v-if="v.cewei_id != null"  src="../../static/image/cheliang.png" mode="widthFix"></image>
									<image v-if="v.cbgl_id != null && v.fcxx_id != null" src="../../static/image/yibiao.png" mode="widthFix"></image>
									<view class="Property">{{v.yssj_fymc}}</view>
								</view>
								<view class="s">转预存</view>
							</view>
						
							<view class="two_line">
								<view class="number">资产编号</view>
								<view class="Vertical">|</view>
								<view class="Location">{{v.zcbh}}</view>
							</view>
						
							<view class="three_line">
								<view class="line_left">
									<view class="start">{{v.yssj_kstime}}</view>
									<view class="horizontal">-</view>
									<view class="end">{{v.yssj_jztime}}</view>
								</view>
								<view class="line_right">￥{{v.yssj_ysje}}</view>
							</view>
						
							<!-- <view class="four_line">
								<view class="times">付款状态：</view>
								<view class="s">转预存</view>
							</view> -->
						</view>
					</template>
				</view>
				<!-- 第四个标签栏结束 -->
			</view>
		</view>
	</view>
</template>

<script>
	import Cache from '@/utils/cache'
	import {
		Expense
	} from '../../common/api';
	export default {
		data() {
			return {
				Inv: 0,
				pages : 1,
				list:[]
			}
		},
		onLoad() {
			this.infoList()
		},
		methods: {
			infoList(status=0){
				const shop_id = Cache.get('shop_id');
				let obj = {
					pages : this.pages,
					shop_id,
					xqgl_id:Cache.get('xqgl_id'),
					yssj_stuats : status
				}
				Expense(obj)
				.then(res=>{
					this.list = [...this.list, ...res.data.data]
				})
			},
			byInv(v) {
				this.Inv = v
				this.list = []
				this.pages = 1
				if( v == 0 ){
					this.infoList(0)
				}else if( v == 1 ){
					this.infoList(1)
				}else if( v == 2 ){
					this.infoList(2)
				}else if( v == 3 ){
					this.infoList(3)
				}
			}
		},
		// 触底的事件
		onReachBottom() {
			this.pages++
			// this.infoList()
			if( this.Inv == 0 ){
				this.infoList(0)
			}else if( this.Inv == 1 ){
				this.infoList(1)
			}else if( this.Inv == 2 ){
				this.infoList(2)
			}else if( this.Inv == 3 ){
				this.infoList(3)
			}
		},
	}
</script>

<style>
	.inv-h-w {
		display: flex;
		justify-content: space-around;
		align-items: center;
		background-color: #fff;
		color: #636363;
		font-size: 26rpx;
		padding: 20rpx 0;
	}

	.content1 {
		margin: 20rpx;
	}

	.content2 {
		margin: 20rpx;
	}

	.content3 {
		margin: 20rpx;
	}

	.content4 {
		margin: 20rpx;
	}

	.inv-h-se {
		position: relative;
		color: #000;
	}

	.inv-h-se::before {
		content: '';
		position: absolute;
		width: 80%;
		height: 5rpx;
		background-color: #ec0c24;
		bottom: -20rpx;
		left: 10%;
		border-radius: 10rpx;
	}

	/* 第一个便签栏 */
	.list {
		background-color: #fff;
		padding: 20rpx 30rpx;
		border-radius: 10rpx;
		font-size: 25rpx;
		color: #9b9b9b;
		margin-bottom: 20rpx;
	}

	.fist_line {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.line_left {
		display: flex;
		align-items: center;
	}

	.line_left image {
		width: 40rpx;
		height: 40rpx;
		margin-right: 15rpx;
	}

	.state {
		color: #2d3542;
	}

	.states {
		color: #c54752;
	}

	.two_line {
		display: flex;
		align-items: center;
		margin: 8rpx 0 8rpx;
	}

	.Vertical {
		margin: 0 8rpx;
	}

	.three_line {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.three_line {
		display: flex;
		align-items: center;
	}

	.line_right {
		font-size: 32rpx;
		color: #000;
	}

	.four_line {
		display: flex;
		align-items: center;
		color: #2d3542;
	}
	.s {
		color: #999;
	}
	/* 第一个便签栏结束 */
</style>
