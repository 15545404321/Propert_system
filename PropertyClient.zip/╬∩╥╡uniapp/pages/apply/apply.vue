<template>
	<view>

		<!-- 背景 -->
		<image class="banner" :src="admanage_pic_top" mode="widthFix"></image>
		<!-- 背景结束 -->

		<!-- 内容 -->
		<view class="content">

			<view class="line">
				<view class="top_text">
					<image src="/static/image/open.png" mode="widthFix"></image>
					<view class="text_p">
						报修描述
					</view>
				</view>
				<view class="textarea">
					<textarea name="" id="" cols="30" rows="10" placeholder="请描述您的问题" v-model="textVal"></textarea>
				</view>
			</view>

			<view class="line">
				<view class="top_text">
					<image src="/static/image/camera.png" mode="widthFix"></image>
					<view class="text_p">
						上传图片
					</view>
				</view>
				<view class="text">
					上传图片，有助于帮助物业更好的为您处理问题
				</view>
				<view class="photo">
					<view id="name">
						<view id="upload" @click="upload()"></view>
					</view>
					<view v-for="(vImg,vIndex) in imgBase64" class="imgBox">
						<image src="../../static/image/cuo1.png" mode="widthFix" class="cuo" @click="del(vIndex)"></image>
						<image :src="vImg" mode="widthFix" class="base64"></image>
					</view>
					<!-- 查看大图 -->
					<view class="bigImg"></view>
				</view>
			</view>

			<view class="line ed">
				<view class="top_text">
					<image src="/static/image/classification.png" mode="widthFix"></image>
					<view class="text_p">
						问题分类
					</view>
				</view>
				<select name="" id="" v-model="selectOption">
					<option value="">请选择</option>
					<option :value="v.bxfl_id" v-for="v in bxfl">{{v.bxfl_name}}</option>
				</select>
			</view>


		</view>

		<view class="submit" @click="submit()">
			确认提交
		</view>
		<!-- 内容结束 -->
	</view>
</template>

<script>
	import Cache from '@/utils/cache'
	import { bxFl,Upload, AdManage} from "../../common/api.js"
	import { pathToBase64 } from "../../utils/img-tools.js"
	export default {
		data() {
			return {
				imgBase64:[],
				textVal:'', // 文本域
				selectOption : "", // 选择框
				bxfl : [],
				num : 1, //给图片id
				admanage_pic_top: ''
			}
		},
		onLoad() {
			let data = {
				xqgl_id : Cache.get('xqgl_id'),
				shop_id : Cache.get('shop_id')
			}
			bxFl(data)
			.then(res=>{
				this.bxfl = res.data.data
			})
			let obj = {
				page_type : 'apply',
				shop_id : Cache.get('shop_id')
			}
			AdManage(obj)
			.then(res=>{
				this.admanage_pic_top = res.data.data.top.admanage_pic
			})
		},
		methods: {
			dealImage2(base64, w, callback) {
				var newImage = new Image();
				var quality = 0.6; //压缩系数0-1之间
				newImage.src = base64;
				newImage.setAttribute("crossOrigin", 'Anonymous'); //url为外域时需要
				var imgWidth, imgHeight;
				newImage.onload = function () {
					imgWidth = this.width;
					imgHeight = this.height;
					var canvas = document.createElement("canvas");
					var ctx = canvas.getContext("2d");
					if (Math.max(imgWidth, imgHeight) > w) {
						if (imgWidth > imgHeight) {
							canvas.width = w;
							canvas.height = w * imgHeight / imgWidth;
						} else {
							canvas.height = w;
							canvas.width = w * imgWidth / imgHeight;
						}
					} else {
						canvas.width = imgWidth;
						canvas.height = imgHeight;
						quality = 0.6;
					}
					ctx.clearRect(0, 0, canvas.width, canvas.height);
					ctx.drawImage(this, 0, 0, canvas.width, canvas.height);
					var base64 = canvas.toDataURL("image/jpeg", quality);
					callback(base64); //必须通过回调函数返回，否则无法及时拿到该值
				}
			},
			upload() {
				if( this.imgBase64.length > 8){
					uni.showToast({
						title:'最多放置9张图片',
						icon:'none'
					})
					return
				}
				let _this = this
				uni.chooseImage({
					count: 9,
					sizeType: ['original', 'compressed'],
					sourceType: ['camera', 'album'],
					success: (res) => {
						uni.showLoading({
							title: '图片上传中'
						});
						if (res.tempFiles[0].size <= 10 * 1024 * 1024) {
							// 图片转为base64
							pathToBase64(res.tempFilePaths[0]).then(path => {
								uni.hideLoading();
								// 图片自带id
								// let imgObj = {}
								// imgObj['id'] = this.num
								// imgObj['path'] = path
								// this.num += 1
								// end
								
								// 图片压缩
								// this.dealImage2(path, 100, function (aa) {
								// 	_this.imgBase64.push(aa)
								// })
								
								this.imgBase64.push(path);
							}).catch(error => {
								uni.hideLoading();
							})
						} else {
							uni.hideLoading();
							this.errorToast = "请上传小于10MB的图片";
						}
					}
					
				});
			},
			submit(){
				if( this.textVal == "" ){
					uni.showToast({
						title:'请输入问题描述',
						icon:'none'
					})
					return
				}
				if( this.selectOption == "" ){
					uni.showToast({
						title:'请选择问题分类',
						icon:'none'
					})
					return
				}
				let obj = {
					xqgl_id : Cache.get('xqgl_id'),
					shop_id : Cache.get('shop_id'),
					value : this.textVal,
					img : this.imgBase64,
					sele : this.selectOption
				}
				uni.showLoading({
					title:'提交中'
				})
				Upload(obj)
				.then(res=>{
					if( res.status == 200 ){
						uni.hideLoading();
						uni.showToast({
							title:'提交成功',
							icon:'none'
						})
						this.textVal = ''
						this.imgBase64 = []
						this.selectOption = ''
					}
				})
				// console.log(this.imgBase64);
			},
			// 删除图片
			del(id){
				this.imgBase64.splice(id, 1)
			}
		}
	}
</script>

<style>
	body {
		background-color: #ededed;
	}

	/* 背景 */
	.banner {
		width: 100%;
	}

	/* 背景结束 */
	/* 内容 */
	.content {
		background-color: #fff;
		margin: 20rpx;
		border-radius: 10rpx;
		padding: 20rpx;
	}

	.top_text {
		display: flex;
		align-items: center;
	}

	.top_text image {
		width: 40rpx;
		height: 40rpx;
	}

	.text_p {
		margin-left: 10rpx;
		font-size: 28rpx;
		font-weight: 600;
	}

	.textarea {
		height: 200rpx;
		background-color: #ededed;
		padding: 20rpx;
		border-radius: 10rpx;
		margin-top: 10rpx;
	}

	.textarea textarea {
		font-size: 24rpx;
	}

	.line {
		border-bottom: solid 2rpx #ededed;
		padding-bottom: 20rpx;
		margin: 20rpx;
	}

	.text {
		font-size: 24rpx;
		color: #b6b6b6;
		margin: 10rpx 0;
	}

	/* 内容结束 */
	/* 图片上传 */
	/* 图片上传 */
	#name {
		display: flex;
		position: relative;
	}

	#upload {
		width: 100rpx;
		height: 100rpx;
		margin-right: 10rpx;
		padding: 10rpx;
		border: 2rpx solid #DADADA;
		margin-bottom: 10rpx;
		background: url("../../static/image/scupload.png") no-repeat;
		background-color: #efefef;
		background-size: 100% 100%;
	}
	.photo{
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		margin: 20rpx 0 0;
	}
	.base64 {
		width: 120rpx;
		height: 120rpx;
		margin-right: 20rpx;
	}
	.imgBox {
		position: relative;
	}
	.cuo {
		width: 50rpx;
		position: absolute;
		right: -6rpx;top: -22rpx;
		z-index: 9999;
	}

	.bigImg {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		display: none;
		justify-content: center;
		align-items: center;
		width: 100%;
		background: rgba(0, 0, 0, .3);
	}

	.bigImg image {
		width: 100%;
	}

	/* 下拉框 */
	.line.ed {
		display: flex;
		align-items: center;
	}

	select {
		margin-left: 20rpx;
		border: 0;
		width: 350rpx;
		height: 40rpx;
		background-color: #ededed;
	}

	/* 提交按钮 */
	.submit {
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: #f92f2f;
		margin: 0 40rpx;
		padding: 20rpx;
		border-radius: 50rpx;
		color: #fff;
		font-size: 30rpx;
	}
</style>
