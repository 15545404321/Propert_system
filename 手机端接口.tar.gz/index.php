<?php
header("Content-type:text/html;charset=utf-8");

header('Access-Control-Allow-Origin: *'); // * 允许所有线上请求，不包括本地请求

// header('Access-Control-Allow-Origin: 192.168.1.41:8080'); // 后端不能存 session

header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept,Cookie,Set-Cookie");
header("Access-Control-Expose-Headers: Origin, X-Requested-With, Content-Type, Accept,Cookie,Set-Cookie,Api-Type,Api-Token,User-Form-Token,User-Token,Token");
header('Access-Control-Allow-Credentials:true');

$server = $_SERVER;

$path = $server['REQUEST_URI'];

$path = ltrim($path, '/');

$controller_method = explode('/', $path);

$app = $controller_method[0];

$controller = ucfirst($controller_method[1]);

$method = $controller_method[2];

if (empty(explode('?', $controller_method[0])[0])) {

    $param = '';

    if (!empty($server['QUERY_STRING'])) {

        $param = '?'.$server['QUERY_STRING'];

    }

    header('Location: /mobile/#/'.$param);
}

require_once __DIR__.'/app/'.$app.'/controller/'.$controller.'.php';

require_once __DIR__.'/core.php';

require_once __DIR__.'/utils/wxoauth/WxOauth.php';

$method = explode('?', $method)[0];

$obj = new $controller();

$obj->$method();

exit;
