<?php

namespace utils\oss;

/*require('../../php_to_sdk/src/Qiniu/Auth.php');
require('../../php_to_sdk/src/Qiniu/Storage/UploadManager.php');*/
require_once __DIR__ . '/../../php_to_sdk/src/Qiniu/Auth.php';
require_once __DIR__ . '/../../php_to_sdk/src/Qiniu/Storage/UploadManager.php';

use Qiniu\Auth;
use Qiniu\Storage\UploadManager;

class QnyOssService
{
    public $accessKey;

    public $secretKey;

    public $bucket;

    public $url;

    public $pipeline;

    public function __construct()
    {
        $this->accessKey = "7i9oOce4nw5HnWfn9IjEvpXSWk4hChwVTQoXnpLz";
        $this->secretKey = "pGf0iV1TcHBjI3MPR4uj2tt9E4Cdy8MjbdMhU7AN";
        $this->bucket = "dmk1";
        $this->url = "http://rpw6zdy1s.hb-bkt.clouddn.com";
        $this->pipeline = "";
    }

    public function getToken()
    {
        $auth = new Auth($this->accessKey, $this->secretKey);
        // 生成上传Token
        $time = date('Y-m',time());
        $token = $auth->uploadToken($this->bucket,'home/'.$time.'/');
        return $token;
    }
}
