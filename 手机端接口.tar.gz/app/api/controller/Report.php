<?php

//require('../utils/oss/QnyOssService.php');

class Report
{
    public function index() {

        $shop_id = $_GET['shop_id'];
        $xqgl_id = $_GET['xqgl_id'];
        $pages = $_GET['pages'];
        $limit = 10;

        $d['shop_id'] = $shop_id;
        $d['xqgl_id'] = $xqgl_id;
        $d['limit1'] = $limit * ( $pages - 1 );
        $d['limit2'] = $d['limit1'] + $limit;

        $re = D('bxxx', $d);

        $res = $re;

        foreach ($re as $re_key => $re_item) {

            $res[$re_key]['bxxx_cltime'] = date('Y-m-d',$re_item['bxxx_cltime']);

            $bxxx_pic = json_decode($re_item['bxxx_pic'],JSON_UNESCAPED_UNICODE);

            $res[$re_key]['bxxx_index_pic'] = '';

            if (!empty($bxxx_pic)) {
                foreach ($bxxx_pic as $bxxx_pic_key => $bxxx_pic_item) {

                    if ($bxxx_pic_key == 0) {

                        $url = $bxxx_pic_item['url'];

                        if (!strstr($bxxx_pic_item['url'],'http')) {
                            $res[$re_key]['bxxx_index_pic'] = str_replace('/uploads/', C('FILE_DOMAIN').'/uploads/',$url);
                        }

                    }
                }
            }
        }
        
        J($res,'获取成功',200);
    }

    public function details() {

        $shop_id = $_GET['shop_id'];
        $bxxx_id = $_GET['bxxx_id'];

        $d['shop_id'] = $shop_id;
        $d['bxxx_id'] = $bxxx_id;

        $re = D('bxxx', $d)[0];

        $res = $re;

        $res['bxxx_cltime'] = date('Y-m-d',$res['bxxx_cltime']);

        $res['bxxx_time'] = date('Y-m-d',$res['bxxx_time']);

        $bxxx_pic = json_decode($res['bxxx_pic'],JSON_UNESCAPED_UNICODE);

        $res['bxxx_index_pic'] = '';

        unset($res['bxxx_pic']);

        if (!empty($bxxx_pic)) {
            foreach ($bxxx_pic as $bxxx_pic_key => $bxxx_pic_item) {

                $url = $bxxx_pic_item['url'];

                if (!strstr($bxxx_pic_item['url'],'http')) {
                    $url = str_replace('/uploads/', C('FILE_DOMAIN').'/uploads/',$url);
                }

                if ($bxxx_pic_key == 0) {
                    $res['bxxx_index_pic'] = $url;
                }

                $res['bxxx_pic'][] = $url;
            }
        }

        J($res,'获取成功',200);
    }

    public function wyNewsList() {

        $shop_id = $_GET['shop_id'];
        $extra = $_GET['extra'];
        $extra_arr = json_decode($extra,true);
        $pages = $_GET['pages'];
        $limit = 10;

        $d['shop_id'] = $shop_id;
        $d['wzfl_id'] = $extra_arr['place'];
        $d['limit1'] = $limit * ( $pages - 1 );
        $d['limit2'] = $d['limit1'] + $limit;

        $re = D('wzgl', $d);

        $res = $re;

        foreach ($re as $re_key => $re_item) {
            $res[$re_key]['wzgl_time'] = date('Y-m-d',$re_item['wzgl_time']);
            if (strstr($re_item['wzgl_img'],'http')) {
                continue;
            }
            $res[$re_key]['wzgl_img'] = str_replace('/uploads/', C('FILE_DOMAIN').'/uploads/',$re_item['wzgl_img']);
        }

        J($res,'获取成功',200);
    }

    public function newsDetails() {

        $shop_id = $_GET['shop_id'];
        $wzgl_id = $_GET['wzgl_id'];

        $d['shop_id'] = $shop_id;
        $d['wzgl_id'] = $wzgl_id;

        $re = D('wzgl', $d);

        $res = $re;

        foreach ($re as $re_key => $re_item) {
            $res[$re_key]['wzgl_time'] = date('Y-m-d',$re_item['wzgl_time']);
            if (strstr($re_item['wzgl_neirong'],'http')) {
                continue;
            }
            $res[$re_key]['wzgl_neirong'] = str_replace('<img src="', '<img src="'.C('FILE_DOMAIN').'',$re_item['wzgl_neirong']);
        }

        J($res[0],'获取成功',200);
    }


    public function recruitNewsList() {

        $shop_id = $_GET['shop_id'];

        $pages = $_GET['pages'];
        $limit = 10;

        $d['shop_id'] = $shop_id;
        $d['limit1'] = $limit * ( $pages - 1 );
        $d['limit2'] = $d['limit1'] + $limit;

        $re = D('wzgl', $d);

        $res = $re;

        foreach ($re as $re_key => $re_item) {
            $res[$re_key]['wzgl_time'] = date('Y-m-d',$re_item['wzgl_time']);
            if (strstr($re_item['wzgl_img'],'http')) {
                continue;
            }
            $res[$re_key]['wzgl_img'] = str_replace('/uploads/', C('FILE_DOMAIN').'/uploads/',$re_item['wzgl_img']);
        }

        J($res,'获取成功',200);
    }

    public function recruitDetails() {

        $shop_id = $_GET['shop_id'];
        $wzgl_id = $_GET['wzgl_id'];

        $d['shop_id'] = $shop_id;
        $d['wzgl_id'] = $wzgl_id;

        $re = D('wzgl', $d);

        $res = $re;

        foreach ($re as $re_key => $re_item) {
            $res[$re_key]['wzgl_time'] = date('Y-m-d',$re_item['wzgl_time']);
            if (strstr($re_item['wzgl_neirong'],'http')) {
                continue;
            }
            $res[$re_key]['wzgl_neirong'] = str_replace('<img src="', '<img src="'.C('FILE_DOMAIN').'',$re_item['wzgl_neirong']);
        }

        J($res[0],'获取成功',200);
    }

    public function repairSearch() {

        $shop_id = $_GET['shop_id'];
        $type = $_GET['type'];
        $pages = $_GET['pages'];
        $limit = 10;

        $d['b.shop_id'] = $shop_id;
        $d['b.member_id'] = $_SESSION['member']['member_id'];

        $d['limit1'] = $limit * ( $pages - 1 );
        $d['limit2'] = $d['limit1'] + $limit;

        if ($type != 0) {

            if ($type == 2) {

                $d['b.bxxx_start'] = 2;

            } elseif ($type == 1) {

                $d['b.bxxx_start'] = ['where_in',[1,3]];
            }
        }

        $d['join'] = [
            C('PREFIX').'member m' => 'b.member_id=m.member_id'
        ];

        $re = D('bxxx b',$d);

        $res = $re;

        foreach ($re as $re_key => $re_item) {
            $res[$re_key]['bxxx_cltime'] = date('Y-m-d',$re_item['bxxx_cltime']);
        }

        J($res,'获取成功',200);
    }

    function submitBx() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        if ($object) {

            $shop_id = $object['shop_id'];
            $xqgl_id = $object['xqgl_id'];
//            $xqgl_id = 9;
            $member_id = $_SESSION['member']['member_id'];
            $bxxx_miaoshu = $object['value'];
            $bxfl_id = $object['sele'];

            $imgpath = [];

            foreach ($object['img'] as $img) {
                $imgpath[] = saveBaseImg($img);
            }

            $bxxx_pic = json_encode($imgpath,JSON_UNESCAPED_UNICODE);

            $d['bxxx_pic'] = $bxxx_pic;
            $d['shop_id'] = $shop_id;
            $d['xqgl_id'] = $xqgl_id;
            $d['member_id'] = $member_id;
            $d['bxxx_miaoshu'] = $bxxx_miaoshu;
            $d['bxxx_time'] = time();
            $d['bxxx_start'] = 1;
            $d['bxfl_id'] = $bxfl_id;

            D('bxxx', $d, '+');
            J('','提交成功',200);

        } else {
            J('','请求方式错误',400);
        }

    }


    function bxFl() {

        $shop_id = $_GET['shop_id'];
        $xqgl_id = $_GET['xqgl_id'];
        $d['shop_id'] = $shop_id;
        $d['xqgl_id'] = $xqgl_id;

        $res = D('bxfl',$d);

        J($res,'获取成功',200);
    }

    function getQnyToken() {

        $QiNiu = new QnyOssService();
        $upToken = $QiNiu->getToken();
        J($upToken,'获取成功',200);
    }
}
