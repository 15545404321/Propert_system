<?php

class ConTel
{
    public function index() {

        $shop_id = $_GET['shop_id'];
        $xqgl_id = $_GET['xqgl_id'];
        $search_text= $_GET['text'];
        $type= $_GET['type'];
        $extra = $_GET['extra'];
        $extra_arr = json_decode($extra,true);

        $d['dhfl_id'] = $extra_arr['place'];
        $d['shop_id'] = $shop_id;
        $d['bmdh_title'] = ['like',$search_text];
        $d['xqgl_id'] = $xqgl_id;

        if ($type != 0) {
            $d['dhfl_id'] = $type;
        }

        $re = D('bmdh', $d);

        $res = $re;

        J($res,'获取成功',200);
    }

}
