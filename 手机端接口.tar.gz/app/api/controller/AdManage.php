<?php

//require('../utils/oss/QnyOssService.php');

class AdManage
{
    public function index() {

        $shop_id = $_GET['shop_id'];
        $page_type = $_GET['page_type'];

        $d['shop_id'] = $shop_id;

        switch ($page_type) {
            case 'report':
                $d['admanage_page'] = 1;
                break;
            case 'apply':
                $d['admanage_page'] = 2;
                break;
            case 'phone':
                $d['admanage_page'] = 3;
                break;
            case 'mycenter':
                $d['admanage_page'] = 4;
                break;
        }
        $re = D('admanage', $d);
        $res = [];
        switch ($d['admanage_page']) {
            case 1:
            case 2:
            case 3:
                foreach ($re as $re_key =>$re_item) {
                    $re_item['admanage_pic'] = 'http://newwy.jf.ivimoo.com'.$re_item['admanage_pic'];
                    $res['top'] = $re_item;
                }

                break;
            case 4:
                foreach ($re as $re_key =>$re_item) {
                    if ($re_item['admanage_position'] == 1) {
                        $re_item['admanage_pic'] = 'http://newwy.jf.ivimoo.com'.$re_item['admanage_pic'];
                        $res['top'] = $re_item;
                    } else {
                        $re_item['admanage_pic'] = 'http://newwy.jf.ivimoo.com'.$re_item['admanage_pic'];
                        $res['middle'] = $re_item;
                    }
                }
                break;
        }
        J($res,'获取成功',200);
    }

}
