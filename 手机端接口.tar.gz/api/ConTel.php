<?php
header("Content-type:text/html;charset=utf-8");
include('../core.php');

$ConTel = new ConTel();

$fun_name = I('get.c');

$ConTel->$fun_name();

class ConTel
{
    public function index() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $shop_id = $object['shop_id'];
        $search_text= $object['text'];
        $type = $object['type'];

        $d['shop_id'] = $shop_id;
        $d['bmdh_title'] = ['like',$search_text];

        if ($type != 0) {
            $d['dhfl_id'] = $type;
        }

        $re = D('bmdh', $d);

        $res = $re;

        J($res,'获取成功',200);
    }

}
