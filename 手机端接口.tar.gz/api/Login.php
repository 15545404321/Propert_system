<?php

namespace api;

header("Content-type:text/html;charset=utf-8");

require('../utils/wxoauth/WxOauth.php');
include('../core.php');

use utils\wxoauth\WxOauth;

$Login = new Login();

$fun_name = I('get.c');

$Login->$fun_name();

class Login
{
    function oalogin () {

        // TODO 需要传参 shop_id ，判断 appid 及 获取 member 表信息

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $shop_id = $object['shop_id'];

        $appid ="";// appid
        $appsecret ="";// appsecret
        $WxOauth = new WxOauth($appid,$appsecret);

        if (isset($object['code']) && !empty($object['code'])) {
            $res = $WxOauth->getToken($object['code']);

            $openid = $res['openid'];

            if (empty($openid)) {
                J($res,'参数错误，openid获取失败',400);
            }

            $d['shop_id'] = $shop_id;
            $d['openid'] = $openid;

            $re = D('member', $d);
            $res['member_id'] = $re[0]['member_id'];
            $res['xqgl_id'] = $re[0]['xqgl_id'];
            if (!empty($re)) {
                J($res,'获取成功',200);
            } else {
                J($openid,'获取成功',201);
            }
        } else {
            $redirect_uri = '';
            $uri = $WxOauth->getCode($redirect_uri);
            J($uri,'获取成功',200);
        }
    }

    function claim() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $xq_lou_dan_fc = $object['xq_lou_dan_fc'];
        $checked = $object['checked'];
        $openid = $object['openid'];
        $rz_name = $object['rz_name'];

//        dump($xq_lou_dan_fc);
//        dump($checked);
//        dump($openid);
//        exit;
//        $xq_lou_dan_fc = '1,2,3,3008';
//        $checked = $object['checked'];
//        $openid = 'o8VH75uYCbFiTdntPGdYQuhNk9eQ';

        $xq_lou_dan_fc_arr = explode(',',$xq_lou_dan_fc);

        $d['fcxx_id'] = $xq_lou_dan_fc_arr[3];

        $fcxx = D('fcxx', $d);

        $member_id = $fcxx[0]['member_id'];
        $shop_id = $fcxx[0]['shop_id'];
        $xqgl_id = $fcxx[0]['xqgl_id'];


        if (empty($member_id)) { // 如果 该房产信息 没有户主

//            建立 member 一条新数据，认证状态为[未认证]]
            if ($checked == 1)  { // 如果是户主

                $insert['khlx_id'] = 1;
                $insert['openid'] = $openid;
                $insert['shop_id'] = $shop_id;
                $insert['xqgl_id'] = $xqgl_id;
                $insert['member_name'] = $rz_name;
                $insert['member_rzzt'] = 0;
                $member_id = D('member', $insert, '+'); // 创建 并 认领会员信息

                // 同时将房产改为我
                $update_fcxx_member['member_id'] = $member_id;
                D('fcxx',$update_fcxx_member,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));

                // TODO J

            } else { // 如果不是户主，建立2条，将member_idx 写入该用户id

                // 建立自己信息
                $insert1['khlx_id'] = $checked;
                $insert1['openid'] = $openid;

                $insert1['shop_id'] = $shop_id;
                $insert1['xqgl_id'] = $xqgl_id;

                $insert1['member_rzzt'] = 0;
                $insert1['member_name'] = $rz_name;
                $member_id = D('member', $insert1, '+'); // 创建 并 认领会员信息

                // 建立户主信息、并把家庭成员加上我
                $insert1['member_idx'] = $member_id;
                $insert1['member_name'] = $fcxx[0]['fcxx_fjbh'].'户主';
                $member_id_main = D('member', $insert1, '+'); // 户主、加家庭成员 这时户主的openid==null;

                // 同时将房产改为我的户主
                $update_fcxx_member1['member_id'] = $member_id_main;
                D('fcxx',$update_fcxx_member1,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
            }

        } else { // 有户主

            $w['member_id'] = $member_id; // 户主的id
            $member_info = D('member',$w);

            if (!empty($member_info[0]['openid'])) { // 户主申请认证了
                // 查询 提交人的 openid
                if ($checked != 1) { // 家庭成员

                    // 查询本物业小区是否有我的信息
                    $select['openid'] = $openid;
                    $select['xqgl_id'] = $xqgl_id;
                    $member_wo = D('member',$select); // 我的信息

                    if (empty($member_wo)) {
                        // 如果没有我，创建我的会员数据
                        $insert1['khlx_id'] = $checked;
                        $insert1['openid'] = $openid;

                        $insert1['shop_id'] = $shop_id;
                        $insert1['xqgl_id'] = $xqgl_id;
                        $insert1['member_rzzt'] = 0;
                        $insert1['member_name'] = $rz_name;
                        $member_id_wo = D('member', $insert1, '+'); // 创建 并 认领会员信息

                        // 将我的户主的家庭成员加上我
                        $member_idx_arr = explode(',',$member_info[0]['member_idx']);
                        $member_idx_arr[] = $member_id_wo;
                        $update_main['member_idx'] = implode(',',array_unique($member_idx_arr)); // 户主信息的家庭成员 里添加我的id
                        D('member',$update_main,array('member_id'=>$member_id));

                        /*$update['openid'] = $openid;

                        D('member',$update,array('member_id'=>$member_wo[0]['member_id'])); // 更新我的openid

                        $member_idx_arr = explode(',',$member_info[0]['member_idx']);

                        $member_idx_arr[] = $member_wo[0]['member_id'];

                        $update_main['member_idx'] = implode(',',array_unique($member_idx_arr)); // 户主信息的家庭成员 里添加我的id

                        D('member',$update_main,array('member_id'=>$member_id));*/
                    } else {
                        if($member_info[0]['openid'] == $openid) {
                            J('','您已经绑定过该房产',400);
                        } else {
                            J('','该房产已绑定户主，如果不是您本人，请联系物业确认',400);
                        }
                    }

                    $update_fcxx_member1['member_id'] = $member_id;
                    D('fcxx',$update_fcxx_member1,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
                } else {
                    if($member_info[0]['openid'] == $openid) {
                        J('','您已经绑定过该房产',400);
                    } else {
                        J('','该房产已绑定户主，如果不是您本人，请联系物业确认',400);
                    }
                }
            } else {
                // 户主已绑定 但未认领
                $up_date['openid'] = $openid;
                $up_date['member_name'] = $rz_name;
                $up_date['member_rzzt'] = 0;
                D('member',$up_date,array('member_id'=>$member_id));

                J('','认领已申请',200);
            }

        }

        switch ($checked) {
            case 1 :
                $fcxx_update['member_id'] = $member_id;
                D('fcxx',$fcxx_update,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
                break;
            case 2 :
            case 3 :
                if (empty($member_id)) {
                    J('','请先关联业主',400);
                }

                $member_idx_arr = explode(',',$fcxx[0]['member_idx']);

                $member_idx_arr[] = $member_id;

                $member_idx = implode(',',array_unique($member_idx_arr));

                $fcxx_update1['member_idx'] = $member_idx;

                D('fcxx',$fcxx_update1,array('fcxx_id'=>$xq_lou_dan_fc_arr[3]));
                break;
        }

        J('','',200);
    }

    function getXqLouDanFcList() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $shop_id = $object['shop_id'];

        if (empty($shop_id)) {
            $shop_id = 1;
        }

        $x['shop_id'] = $shop_id;

        $xqgl = D('xqgl', $x);

        $data = [];

        foreach ($xqgl as $xqgl_key => $xqgl_item) {
            $data[$xqgl_key] = [
                'text' => $xqgl_item['xqgl_name'],
                'value' => $xqgl_item['xqgl_id'],
                'children' =>[],
            ];

            $l['xqgl_id'] = $xqgl_item['xqgl_id'];
            $louyu_dan = D('louyu', $l);

            $lou = [];
            $dan = [];
            foreach ($louyu_dan as $louyu_dan_key => $louyu_dan_value){
                if (empty($louyu_dan_value['louyu_pid'])) {
                    $lou[] = $louyu_dan_value;
                }
                $dan[] = $louyu_dan_value;
            }

            foreach ($lou as $lou_key => $lou_value){

                $data[$xqgl_key]['children'][$lou_key] = [
                    'text' => $lou_value['louyu_name'],
                    'value' => $lou_value['louyu_id'],
                    'children' =>[],
                ];

                $dan_c = [];
                foreach ($dan as $dan_key => $dan_value) {

                    if ($lou_value['louyu_id'] == $dan_value['louyu_id']
                        || $lou_value['louyu_id'] == $dan_value['louyu_pid']) {
                        $dan_c[] = $dan_value;
                    }

                }

                foreach ($dan_c as $dan_c_key => $dan_c_value) {
                    $data[$xqgl_key]['children'][$lou_key]['children'][$dan_c_key] = [
                        'text' => $dan_c_value['louyu_name'],
                        'value' => $dan_c_value['louyu_id'],
                        'children' =>[],
                    ];

                    $f['louyu_id'] = $dan_c_value['louyu_id'];
                    $fcxx = D('fcxx', $f);

                    foreach ($fcxx as $fcxx_key => $fcxx_value) {
                        $data[$xqgl_key]['children'][$lou_key]['children'][$dan_c_key]['children'][$fcxx_key] = [
                            'text' => $fcxx_value['fcxx_fjbh'],
                            'value' => $fcxx_value['fcxx_id']
                        ];
                    }
                }

            }
        }

        J($data,'获取成功',200);
    }

    public function getXqglList() {

        $json= file_get_contents('php://input');

        $object = json_decode($json,true);

        $shop_id = $object['shop_id'];

        $x['shop_id'] = $shop_id;

        $xqgl = D('xqgl', $x);

        J($xqgl,'获取成功',200);
    }

    public function changeXqglId() {

    }

    public function Qyjxh() {
        // 企业家协会接口
        $appid ="wx6d6063d108b4eafe";
        $appsecret ="2f5e8067d683a305be5ba29e223d1820";
        if ($_GET['state'] != 'codeopenid') {

            $redirect_uri = urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING']);

            $url='https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$appid.'&redirect_uri='.$redirect_uri.'&scope=snsapi_base&state=codeopenid&response_type=code#wechat_redirect';
            Header("Location: $url");exit;
        } else {
            $url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appid.'&secret='.$appsecret.'&code='.$_GET['code'].'&grant_type=authorization_code';
            $rs = json_decode(file_get_contents($url),1);

            if ($rs['errcode']) {
                return false;
            } else {
                Header("Location: http://qyjxh.jf.ivimoo.com/wap/button.php?openid=".$rs['openid']);exit;
            }
        }
    }

}

/*
 * 1 判断是否登录，已登录就无需登录，否则调用登录接口
 * 2 登录接口查询获取openid
 * 3 用openid去 member 表查是否存在相关数据
 * 4 如果有则登录完成
 * 5 如果没有则将openid 返给前端
 * 6 前端和者选着的房产信息一起提交后台
 * 6.1 获取小区数据
 * 6.2 提交
 * 7 之后过程如图
 * 7.1 并标注默认登录小区
 *
 * 8 后台认证状态审核
 *
 *
 * 9 切换小区 切换 member_id 和 xqgl_id，并标注为下次默认登录小区
 * 10 第一次登录该小区需要审核
 * */

/*{
    text: '九州花园',
    value: '1',
    children: [{
        text: 'A做',
        value: '2',
        children: [{
            text: '3单元',
            value: '3',
            children: [{
                text: '1002',
                value: '4'
            }]
        }]
    }],
}, {
    text: '江苏省',
    alue: '320000',
    children: [{
        text: '南京市',
        value: '320100'
    }],
},*/
